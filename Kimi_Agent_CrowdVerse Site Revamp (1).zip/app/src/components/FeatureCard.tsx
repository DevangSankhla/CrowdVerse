import type { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  size: 'large' | 'tall' | 'wide' | 'standard';
}

const sizeClasses = {
  large: 'md:col-span-2 md:row-span-2',
  tall: 'md:row-span-2',
  wide: 'md:col-span-2',
  standard: '',
};

export default function FeatureCard({
  icon: Icon,
  title,
  description,
  size,
}: FeatureCardProps) {
  return (
    <div
      className={`group relative p-6 sm:p-8 rounded-2xl bg-cv-black border border-white/5 
        transition-all duration-500 hover:border-cv-green/30 hover:shadow-glow card-glow
        ${sizeClasses[size]}`}
    >
      {/* Icon */}
      <div
        className="w-12 h-12 rounded-xl bg-cv-green/10 border border-cv-green/20 
          flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-cv-green/20 
          transition-all duration-500"
      >
        <Icon className="w-6 h-6 text-cv-green" />
      </div>

      {/* Content */}
      <h3 className="font-space font-bold text-lg sm:text-xl text-cv-off-white mb-3">
        {title}
      </h3>
      <p className="text-cv-light-gray/70 leading-relaxed text-sm sm:text-base">
        {description}
      </p>

      {/* Hover indicator */}
      <div className="absolute bottom-6 right-6 w-8 h-8 rounded-full bg-cv-green/0 
        group-hover:bg-cv-green/10 flex items-center justify-center transition-all duration-500">
        <div className="w-2 h-2 rounded-full bg-cv-green opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </div>
  );
}
