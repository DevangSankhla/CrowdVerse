import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  ArrowRight, 
  Brain, 
  Users, 
  Zap, 
  BarChart3, 
  Newspaper, 
  Sparkles,
  ChevronRight,
  Shield,
  Clock,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ParticleBackground from '@/components/ParticleBackground';
import MarketTicker from '@/components/MarketTicker';
import IntelligencePanel from '@/components/IntelligencePanel';
import FeatureCard from '@/components/FeatureCard';
import PredictionCard from '@/components/PredictionCard';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: Brain,
    title: 'AI-Powered Analysis',
    description: 'Our advanced AI algorithms analyze millions of data points to deliver actionable market insights and sentiment analysis.',
    size: 'large',
  },
  {
    icon: Users,
    title: 'Community Consensus',
    description: 'Tap into the collective wisdom of thousands of investors. See what the crowd thinks in real-time.',
    size: 'tall',
  },
  {
    icon: Zap,
    title: 'Real-Time Data',
    description: 'Live market feeds, instant updates, and real-time sentiment tracking across all major assets.',
    size: 'wide',
  },
  {
    icon: Shield,
    title: 'Secure & Private',
    description: 'Your data is encrypted and protected. We never share your personal information.',
    size: 'standard',
  },
];

const predictions = [
  {
    id: 1,
    question: 'Will SpaceX land humans on Mars this year?',
    category: 'Technology',
    votes: 12543,
    yesPercentage: 23,
    noPercentage: 77,
    trending: true,
  },
  {
    id: 2,
    question: 'Will NIFTY 50 cross 25,000 by end of 2025?',
    category: 'Markets',
    votes: 8921,
    yesPercentage: 68,
    noPercentage: 32,
    trending: true,
  },
  {
    id: 3,
    question: 'Will Bitcoin reach $100,000 this year?',
    category: 'Crypto',
    votes: 15678,
    yesPercentage: 54,
    noPercentage: 46,
    trending: false,
  },
];

export default function Landing() {
  const heroRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero entrance animations
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      tl.fromTo(
        headlineRef.current,
        { y: 60, opacity: 0 },
        { y: 0, opacity: 1, duration: 1 }
      )
        .fromTo(
          subheadRef.current,
          { y: 40, opacity: 0, filter: 'blur(10px)' },
          { y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.8 },
          '-=0.5'
        )
        .fromTo(
          ctaRef.current,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6 },
          '-=0.3'
        );

      // Scroll-triggered animations for sections
      gsap.utils.toArray<HTMLElement>('.gsap-reveal').forEach((el) => {
        gsap.fromTo(
          el,
          { y: 50, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <div className="relative">
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Particle Background */}
        <ParticleBackground />

        {/* Hero Content */}
        <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cv-green/10 border border-cv-green/20 mb-8 animate-fade-in">
            <Sparkles className="w-4 h-4 text-cv-green" />
            <span className="text-sm font-medium text-cv-green">India's First AI Community Intelligence Platform</span>
          </div>

          {/* Headline */}
          <h1
            ref={headlineRef}
            className="font-space font-bold text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-cv-off-white leading-tight mb-6"
          >
            Where <span className="gradient-text">AI Intelligence</span>
            <br />
            Meets <span className="text-cv-green">Collective Wisdom</span>
          </h1>

          {/* Subheadline */}
          <p
            ref={subheadRef}
            className="text-lg sm:text-xl text-cv-light-gray/70 max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Track markets, predict trends, and make informed decisions with real-time 
            AI-generated insights and crowd sentiment analysis.
          </p>

          {/* CTAs */}
          <div ref={ctaRef} className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/early-access">
              <Button
                size="lg"
                className="bg-cv-green text-cv-black hover:bg-cv-green-dark font-semibold px-8 py-6 text-lg rounded-xl transition-all duration-300 hover:shadow-glow-lg group"
              >
                Get Early Access
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link to="/markets">
              <Button
                size="lg"
                variant="outline"
                className="border-white/20 text-cv-off-white hover:bg-white/5 hover:border-white/40 px-8 py-6 text-lg rounded-xl transition-all duration-300"
              >
                Explore Markets
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {[
              { value: '50K+', label: 'Active Users' },
              { value: '1M+', label: 'Predictions Made' },
              { value: '99.9%', label: 'Uptime' },
              { value: '24/7', label: 'AI Monitoring' },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="font-space font-bold text-2xl sm:text-3xl text-cv-green mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-cv-light-gray/50">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-white/20 flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-cv-green rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Market Ticker */}
      <MarketTicker />

      {/* Intelligence Panels Section */}
      <section className="py-24 bg-cv-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 gsap-reveal">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cv-green/10 border border-cv-green/20 mb-4">
              <Brain className="w-4 h-4 text-cv-green" />
              <span className="text-xs font-medium text-cv-green uppercase tracking-wider">AI-Powered</span>
            </div>
            <h2 className="font-space font-bold text-3xl sm:text-4xl md:text-5xl text-cv-off-white mb-4">
              Intelligence Panels
            </h2>
            <p className="text-cv-light-gray/70 max-w-2xl mx-auto text-lg">
              Three powerful ways to stay ahead of the market with AI-driven insights and community sentiment.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 perspective-1000">
            <IntelligencePanel
              icon={Newspaper}
              title="AI News Summaries"
              description="Get concise, AI-generated summaries of market news with sentiment analysis and key takeaways."
              link="/news"
              color="blue"
            />
            <IntelligencePanel
              icon={Sparkles}
              title="Community Predictions"
              description="Participate in prediction markets and see what the crowd thinks about future events."
              link="/predictions"
              color="purple"
            />
            <IntelligencePanel
              icon={BarChart3}
              title="Real-Time Markets"
              description="Track stocks, crypto, and commodities with live prices, charts, and AI sentiment scores."
              link="/markets"
              color="green"
            />
          </div>
        </div>
      </section>

      {/* Features Bento Grid */}
      <section className="py-24 bg-cv-secondary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 gsap-reveal">
            <h2 className="font-space font-bold text-3xl sm:text-4xl md:text-5xl text-cv-off-white mb-4">
              Why CrowdVerse?
            </h2>
            <p className="text-cv-light-gray/70 max-w-2xl mx-auto text-lg">
              Built for the modern investor who values both data-driven insights and collective intelligence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 auto-rows-fr">
            {features.map((feature, index) => (
              <FeatureCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                size={feature.size as 'large' | 'tall' | 'wide' | 'standard'}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Predictions Preview */}
      <section className="py-24 bg-cv-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 gsap-reveal">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 mb-4">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-medium text-purple-400 uppercase tracking-wider">Community Consensus</span>
              </div>
              <h2 className="font-space font-bold text-3xl sm:text-4xl md:text-5xl text-cv-off-white mb-4">
                What's the Verdict?
              </h2>
              <p className="text-cv-light-gray/70 max-w-xl text-lg">
                Join thousands of participants in predicting the future of tech, finance, and global markets.
              </p>
            </div>
            <Link to="/predictions" className="mt-6 md:mt-0">
              <Button variant="outline" className="border-white/20 text-cv-off-white hover:bg-white/5 group">
                View All Predictions
                <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {predictions.map((prediction) => (
              <PredictionCard key={prediction.id} prediction={prediction} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-cv-green/5 via-transparent to-purple-500/5" />
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 gsap-reveal">
          <h2 className="font-space font-bold text-3xl sm:text-4xl md:text-5xl text-cv-off-white mb-6">
            Ready to Join the Intelligence Revolution?
          </h2>
          <p className="text-cv-light-gray/70 text-lg mb-10 max-w-2xl mx-auto">
            Be among the first to experience India's most advanced AI-powered community intelligence platform. 
            Get early access and shape the future of market analysis.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/early-access">
              <Button
                size="lg"
                className="bg-cv-green text-cv-black hover:bg-cv-green-dark font-semibold px-8 py-6 text-lg rounded-xl transition-all duration-300 hover:shadow-glow-lg"
              >
                Get Early Access
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
          
          {/* Trust badges */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-8">
            {[
              { icon: Shield, label: 'Secure Platform' },
              { icon: Clock, label: 'Real-Time Data' },
              { icon: Globe, label: 'Made in India' },
            ].map((badge, index) => {
              const Icon = badge.icon;
              return (
                <div key={index} className="flex items-center gap-2 text-cv-light-gray/50">
                  <Icon className="w-5 h-5" />
                  <span className="text-sm">{badge.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
