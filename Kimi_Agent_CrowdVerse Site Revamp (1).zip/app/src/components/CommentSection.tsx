import { useState } from 'react';
import { MessageSquare, ThumbsUp, Reply, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface Comment {
  id: string;
  author: string;
  avatar?: string;
  content: string;
  timestamp: string;
  likes: number;
  replies: Comment[];
}

interface CommentSectionProps {
  comments: Comment[];
  onAddComment?: (content: string) => void;
  onReply?: (commentId: string, content: string) => void;
  onLike?: (commentId: string) => void;
}

function CommentItem({ 
  comment, 
  onReply, 
  onLike,
  depth = 0 
}: { 
  comment: Comment; 
  onReply?: (commentId: string, content: string) => void;
  onLike?: (commentId: string) => void;
  depth?: number;
}) {
  const [isReplying, setIsReplying] = useState(false);
  const [replyContent, setReplyContent] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(comment.likes);

  const handleLike = () => {
    if (isLiked) {
      setLikeCount(prev => prev - 1);
    } else {
      setLikeCount(prev => prev + 1);
    }
    setIsLiked(!isLiked);
    onLike?.(comment.id);
  };

  const handleSubmitReply = () => {
    if (replyContent.trim()) {
      onReply?.(comment.id, replyContent);
      setReplyContent('');
      setIsReplying(false);
    }
  };

  return (
    <div className={`${depth > 0 ? 'ml-12 mt-4' : 'mt-4'} border-l-2 border-white/5 pl-4`}>
      <div className="flex items-start gap-3">
        <Avatar className="w-8 h-8 bg-cv-green/20">
          <AvatarFallback className="text-xs text-cv-green font-medium">
            {comment.author.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-cv-off-white text-sm">{comment.author}</span>
            <span className="text-xs text-cv-light-gray/50">{comment.timestamp}</span>
          </div>
          <p className="text-cv-light-gray/80 text-sm leading-relaxed mb-2">{comment.content}</p>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={handleLike}
              className={`flex items-center gap-1 text-xs transition-colors ${
                isLiked ? 'text-cv-green' : 'text-cv-light-gray/50 hover:text-cv-green'
              }`}
            >
              <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
              <span>{likeCount}</span>
            </button>
            <button 
              onClick={() => setIsReplying(!isReplying)}
              className="flex items-center gap-1 text-xs text-cv-light-gray/50 hover:text-cv-green transition-colors"
            >
              <Reply className="w-3.5 h-3.5" />
              <span>Reply</span>
            </button>
          </div>

          {isReplying && (
            <div className="flex items-center gap-2 mt-3">
              <Input
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Write a reply..."
                className="flex-1 bg-cv-dark-gray border-white/10 text-cv-off-white text-sm placeholder:text-cv-light-gray/40"
                onKeyDown={(e) => e.key === 'Enter' && handleSubmitReply()}
              />
              <Button 
                size="sm" 
                onClick={handleSubmitReply}
                className="bg-cv-green text-cv-black hover:bg-cv-green-dark"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Nested Replies */}
      {comment.replies?.length > 0 && (
        <div className="mt-4">
          {comment.replies.map((reply) => (
            <CommentItem 
              key={reply.id} 
              comment={reply} 
              onReply={onReply}
              onLike={onLike}
              depth={depth + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function CommentSection({ 
  comments, 
  onAddComment, 
  onReply, 
  onLike 
}: CommentSectionProps) {
  const [newComment, setNewComment] = useState('');

  const handleSubmit = () => {
    if (newComment.trim()) {
      onAddComment?.(newComment);
      setNewComment('');
    }
  };

  return (
    <div className="mt-6 pt-6 border-t border-white/5">
      <div className="flex items-center gap-2 mb-4">
        <MessageSquare className="w-4 h-4 text-cv-light-gray/50" />
        <span className="text-sm text-cv-light-gray/50">
          {comments.length === 0 ? 'No comments yet. Be the first to share.' : `${comments.length} comments`}
        </span>
      </div>

      {/* Add Comment */}
      <div className="flex items-center gap-2 mb-6">
        <Input
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Share your thoughts..."
          className="flex-1 bg-cv-dark-gray border-white/10 text-cv-off-white placeholder:text-cv-light-gray/40"
          onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
        />
        <Button 
          onClick={handleSubmit}
          className="bg-cv-green text-cv-black hover:bg-cv-green-dark"
        >
          POST
        </Button>
      </div>

      {/* Comments List */}
      <div className="space-y-2">
        {comments.map((comment) => (
          <CommentItem 
            key={comment.id} 
            comment={comment} 
            onReply={onReply}
            onLike={onLike}
          />
        ))}
      </div>
    </div>
  );
}
