import { useState } from 'react';
import { ChevronDown, ChevronUp, RefreshCw, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface IntelligenceSection {
  title: string;
  icon: string;
  content: string;
}

interface AIIntelligencePanelProps {
  sections: IntelligenceSection[];
  sentiment?: 'bullish' | 'bearish' | 'neutral';
  onRefresh?: () => void;
  isLoading?: boolean;
}

export default function AIIntelligencePanel({ 
  sections, 
  sentiment = 'neutral',
  onRefresh,
  isLoading = false
}: AIIntelligencePanelProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  const sentimentColors = {
    bullish: 'text-green-400 bg-green-500/10 border-green-500/20',
    bearish: 'text-red-400 bg-red-500/10 border-red-500/20',
    neutral: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
  };

  const sentimentLabels = {
    bullish: 'BULLISH',
    bearish: 'BEARISH',
    neutral: 'NEUTRAL',
  };

  return (
    <div className="mt-6 pt-6 border-t border-white/5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-purple-400" />
          </div>
          <div>
            <h4 className="font-semibold text-cv-off-white text-sm">Quick Intelligence Panel</h4>
            <p className="text-xs text-cv-light-gray/50">AI-generated analysis</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${sentimentColors[sentiment]}`}>
            Sentiment: {sentimentLabels[sentiment]}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={onRefresh}
            disabled={isLoading}
            className="text-cv-light-gray/50 hover:text-cv-green"
          >
            <RefreshCw className={`w-4 h-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh AI Insights
          </Button>
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded-lg hover:bg-white/5 transition-colors"
          >
            {isExpanded ? (
              <ChevronUp className="w-5 h-5 text-cv-light-gray/50" />
            ) : (
              <ChevronDown className="w-5 h-5 text-cv-light-gray/50" />
            )}
          </button>
        </div>
      </div>

      {/* Content */}
      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sections.map((section, index) => (
            <div 
              key={index} 
              className="p-4 rounded-xl bg-cv-dark-gray/50 border border-white/5"
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-purple-400 text-xs">{section.icon}</span>
                <h5 className="text-xs font-medium text-cv-light-gray/70 uppercase tracking-wider">
                  {section.title}
                </h5>
              </div>
              <p className="text-sm text-cv-light-gray/80 leading-relaxed">
                {section.content}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
