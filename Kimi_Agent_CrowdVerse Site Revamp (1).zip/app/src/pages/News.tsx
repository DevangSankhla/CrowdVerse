import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Newspaper, 
  Search,
  Filter
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import NewsPanel from '@/components/NewsPanel';

gsap.registerPlugin(ScrollTrigger);

// Comprehensive news data matching the old website
const newsData = [
  {
    id: 'news-1',
    title: "Pakistan's T20 WC boycott unlikely, team to leave for Colombo on Feb 2: Sources",
    summary: "Lahore: The Pakistan Cricket Board has already scheduled its T20 World Cup squad to depart for Colombo early on February 2, virtually ruling out any possibility of boycotting either the tournament or...",
    source: "The Times of India",
    category: "Politics",
    timestamp: "Just now",
    readTime: "3 min",
    sentiment: 'neutral' as const,
    aiSections: [
      {
        title: "Global Impact Summary",
        icon: "●",
        content: "This development reflects the rapid digitalization and modernization of India's core infrastructure. The shift towards B+ systems and AI-integrated healthcare/finance is reducing transaction costs and increasing transparency. This creates a more resilient economic environment, less susceptible to traditional supply chain disruptions."
      },
      {
        title: "Crowd Sentiment Analysis",
        icon: "●",
        content: "The community is cheering the ease-of-use and accessibility brought by these new digital systems. Sentiment is highly positive among urban populations, with 80%+ support in pulse polls. Discussions center around 'life-quality' improvements and the leapfrogging of traditional development stages."
      },
      {
        title: "Strategic Intelligence",
        icon: "●",
        content: "Technically, this move aligns with the 'Minimum Government, Maximum Governance' framework. Intelligence suggests that this policy will act as a primary driver for sectoral growth in the 2026-2027 fiscal cycle. Strategic planning by domestic firms ahead of this change indicates strong fundamental support for the government's direction."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "The political shift represents a quality upgrade for India's governance. While short-term adjustments will be needed, the medium-to-long-term outlook is bullish. Monitor the upcoming budgetary allocations for specific funding commitments toward this initiative."
      }
    ],
    comments: [
      {
        id: 'c1',
        author: 'shreya',
        content: 'we must.. if the govt keeps to keep increasing taxes',
        timestamp: '1/30/2025, 5:09:00 PM',
        likes: 12,
        replies: []
      },
      {
        id: 'c2',
        author: 'rahul_verma',
        content: 'This is a significant development for South Asian cricket. The geopolitical implications are huge.',
        timestamp: '1/30/2025, 5:15:00 PM',
        likes: 8,
        replies: [
          {
            id: 'c2r1',
            author: 'cricket_fan',
            content: 'Absolutely! PCB has been under pressure for a while now.',
            timestamp: '1/30/2025, 5:20:00 PM',
            likes: 3,
            replies: []
          }
        ]
      }
    ]
  },
  {
    id: 'news-2',
    title: "RBI Maintains Repo Rate at 6.5% for Seventh Consecutive Time",
    summary: "The Reserve Bank of India's Monetary Policy Committee has unanimously decided to keep the policy repo rate unchanged at 6.5%. Governor Shaktikanta Das cited controlled inflation and stable economic growth as key factors behind the decision.",
    source: "Economic Times",
    category: "Economy",
    timestamp: "2 hours ago",
    readTime: "4 min",
    sentiment: 'positive' as const,
    aiSections: [
      {
        title: "Market Impact Analysis",
        icon: "●",
        content: "The rate hold signals RBI's confidence in the current economic trajectory. Markets reacted positively with NIFTY gaining 0.8% post-announcement. Banking stocks showed mixed reactions, with private banks outperforming PSU banks."
      },
      {
        title: "Inflation Outlook",
        icon: "●",
        content: "With CPI inflation at 5.2% within the RBI's tolerance band, the central bank has room to maintain status quo. The focus remains on achieving the 4% target without stifling growth. Food inflation remains a concern at 8.3%."
      },
      {
        title: "Sectoral Implications",
        icon: "●",
        content: "Real estate and auto sectors benefit from stable rates. EMI burdens remain unchanged, supporting consumer sentiment. Export-oriented sectors may face pressure from a stable rupee."
      },
      {
        title: "Future Policy Direction",
        icon: "●",
        content: "Markets pricing in potential rate cuts in Q2 2025 if inflation continues to moderate. Global Fed actions will influence RBI's next moves. Watch for commentary on liquidity management."
      }
    ],
    comments: [
      {
        id: 'c3',
        author: 'investor_kumar',
        content: 'Good decision. Stability is what markets need right now.',
        timestamp: '1/30/2025, 3:30:00 PM',
        likes: 24,
        replies: []
      },
      {
        id: 'c4',
        author: 'economist_view',
        content: 'Expected move. The real question is when will we see rate cuts?',
        timestamp: '1/30/2025, 3:45:00 PM',
        likes: 15,
        replies: [
          {
            id: 'c4r1',
            author: 'market_watcher',
            content: 'Probably Q2 if inflation stays below 5%',
            timestamp: '1/30/2025, 4:00:00 PM',
            likes: 7,
            replies: []
          }
        ]
      }
    ]
  },
  {
    id: 'news-3',
    title: "Bitcoin Surges Past $67,000 as ETF Inflows Reach Record Highs",
    summary: "Bitcoin has broken through the $67,000 resistance level, driven by unprecedented institutional demand. Spot Bitcoin ETFs have seen over $500 million in daily inflows, signaling strong confidence from traditional finance.",
    source: "CoinDesk",
    category: "Crypto",
    timestamp: "4 hours ago",
    readTime: "5 min",
    sentiment: 'positive' as const,
    aiSections: [
      {
        title: "Institutional Adoption",
        icon: "●",
        content: "BlackRock's IBIT and Fidelity's FBTC leading the charge with combined $2B+ AUM. Corporate treasury allocations increasing. Pension funds beginning to explore crypto allocations."
      },
      {
        title: "Technical Analysis",
        icon: "●",
        content: "Breakout above $65K resistance confirms bull trend. Next resistance at $70K psychological level. RSI at 72 indicates overbought conditions - potential pullback to $62K support."
      },
      {
        title: "Market Sentiment",
        icon: "●",
        content: "Fear & Greed Index at 78 (Extreme Greed). Social media sentiment overwhelmingly positive. Google searches for 'Bitcoin' at 12-month highs."
      },
      {
        title: "Risk Factors",
        icon: "●",
        content: "Regulatory uncertainty remains in US and EU. Mt. Gox distributions could create selling pressure. Miner capitulation risk if price drops below $60K."
      }
    ],
    comments: [
      {
        id: 'c5',
        author: 'crypto_bull',
        content: 'To the moon! 100K by March!',
        timestamp: '1/30/2025, 1:00:00 PM',
        likes: 45,
        replies: []
      },
      {
        id: 'c6',
        author: 'cautious_trader',
        content: 'Be careful guys, RSI is showing overbought. Take some profits.',
        timestamp: '1/30/2025, 1:30:00 PM',
        likes: 32,
        replies: [
          {
            id: 'c6r1',
            author: 'hodl_master',
            content: 'Paper hands! We\'re just getting started.',
            timestamp: '1/30/2025, 2:00:00 PM',
            likes: 18,
            replies: []
          }
        ]
      }
    ]
  },
  {
    id: 'news-4',
    title: "Reliance Industries Q3 Results: Net Profit Rises 12% YoY",
    summary: "Reliance Industries reported a consolidated net profit of ₹19,641 crore for Q3 FY25, marking a 12% increase year-over-year. The company's retail and digital services segments showed strong growth.",
    source: "Business Standard",
    category: "Earnings",
    timestamp: "6 hours ago",
    readTime: "5 min",
    sentiment: 'positive' as const,
    aiSections: [
      {
        title: "Financial Performance",
        icon: "●",
        content: "Revenue grew 8% YoY to ₹2.4 lakh crore. EBITDA margins expanded 50bps to 16.2%. Jio ARPU at ₹182, up 2% QoQ. Retail footfall crossed 200 million."
      },
      {
        title: "Segment Analysis",
        icon: "●",
        content: "O2C business stable despite global headwinds. Jio adding 5M subscribers quarterly. Retail expanding to Tier 3/4 cities. New Energy investments accelerating."
      },
      {
        title: "Management Commentary",
        icon: "●",
        content: "Mukesh Ambani emphasized 5G monetization and green energy transition. Capex guidance maintained at ₹1.5 lakh crore for FY25. Share buyback program under consideration."
      },
      {
        title: "Analyst Views",
        icon: "●",
        content: "Morgan Stanley maintains Overweight with TP ₹3,200. CLSA raises target to ₹3,100. Key monitorables: Jio IPO timeline, retail margins, and new energy execution."
      }
    ],
    comments: [
      {
        id: 'c7',
        author: 'reliance_holder',
        content: 'Solid results! Jio IPO when?',
        timestamp: '1/30/2025, 11:00:00 AM',
        likes: 28,
        replies: []
      }
    ]
  },
  {
    id: 'news-5',
    title: "SEBI Proposes New Regulations for Algorithmic Trading",
    summary: "The Securities and Exchange Board of India has proposed stricter regulations for algorithmic trading, including enhanced risk management systems and real-time monitoring requirements.",
    source: "Mint",
    category: "Regulation",
    timestamp: "8 hours ago",
    readTime: "4 min",
    sentiment: 'neutral' as const,
    aiSections: [
      {
        title: "Regulatory Impact",
        icon: "●",
        content: "New rules aim to prevent market manipulation and flash crashes. Compliance costs may increase for brokerages. Smaller algo traders might exit the market."
      },
      {
        title: "Industry Response",
        icon: "●",
        content: "Brokerage associations seeking clarity on implementation timeline. Fintech startups concerned about compliance burden. Large brokers welcoming regulations for level playing field."
      },
      {
        title: "Global Context",
        icon: "●",
        content: "Similar regulations exist in US (SEC) and EU (MiFID II). India's approach more balanced than restrictive. Could attract institutional capital seeking regulated markets."
      },
      {
        title: "Implementation Timeline",
        icon: "●",
        content: "Draft rules open for public comment until March 2025. Expected implementation by Q3 2025. Transition period of 6 months for existing algo traders."
      }
    ],
    comments: [
      {
        id: 'c8',
        author: 'algo_trader',
        content: 'This will kill small algo traders. Only big players will survive.',
        timestamp: '1/30/2025, 9:00:00 AM',
        likes: 19,
        replies: []
      },
      {
        id: 'c9',
        author: 'retail_investor',
        content: 'Good move. Algos have been manipulating markets for too long.',
        timestamp: '1/30/2025, 9:30:00 AM',
        likes: 42,
        replies: []
      }
    ]
  }
];

const categories = ['All', 'Politics', 'Economy', 'Crypto', 'Earnings', 'Regulation', 'Technology', 'Sports'];

export default function News() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const sectionRef = useRef<HTMLDivElement>(null);

  const filteredNews = newsData.filter((news) => {
    const matchesCategory = selectedCategory === 'All' || news.category === selectedCategory;
    const matchesSearch = 
      news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      news.summary.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.gsap-news-item').forEach((el, i) => {
        gsap.fromTo(
          el,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, [filteredNews]);

  return (
    <div ref={sectionRef} className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
              <Newspaper className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="text-xs text-blue-400 uppercase tracking-wider font-medium">Curated Intelligence</div>
              <h1 className="font-space font-bold text-3xl sm:text-4xl text-cv-off-white">
                Global News
              </h1>
            </div>
          </div>
          <p className="text-cv-light-gray/70 max-w-2xl">
            Curated perspective on Politics, Geopolitics, and Foreign Affairs — stripped of market noise.
          </p>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cv-light-gray/50" />
            <Input
              type="text"
              placeholder="Search news..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-cv-secondary border-white/10 text-cv-off-white placeholder:text-cv-light-gray/40"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
            <Filter className="w-5 h-5 text-cv-light-gray/50 flex-shrink-0" />
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={`flex-shrink-0 ${
                  selectedCategory === category
                    ? 'bg-blue-500 text-white hover:bg-blue-600'
                    : 'border-white/10 text-cv-light-gray/70 hover:bg-white/5 hover:text-cv-off-white'
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* News Feed */}
        <div className="space-y-4">
          {filteredNews.map((news) => (
            <div key={news.id} className="gsap-news-item">
              <NewsPanel news={news} />
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredNews.length === 0 && (
          <div className="text-center py-20">
            <Newspaper className="w-16 h-16 text-cv-light-gray/30 mx-auto mb-4" />
            <h3 className="font-space font-semibold text-xl text-cv-off-white mb-2">
              No news found
            </h3>
            <p className="text-cv-light-gray/50">
              Try adjusting your search or filter criteria
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
