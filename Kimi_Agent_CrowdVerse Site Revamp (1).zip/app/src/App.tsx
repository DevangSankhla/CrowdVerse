import { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import News from './pages/News';
import Predictions from './pages/Predictions';
import Markets from './pages/Markets';
import Asset from './pages/Asset';
import Portfolio from './pages/Portfolio';
import EarlyAccess from './pages/EarlyAccess';

gsap.registerPlugin(ScrollTrigger);

// Component to handle dynamic title updates
function TitleUpdater() {
  const location = useLocation();

  useEffect(() => {
    const titles: Record<string, string> = {
      '/': 'CrowdVerse - India\'s First AI Community Intelligence Platform',
      '/dashboard': 'Dashboard - Live Market Overview | CrowdVerse',
      '/news': 'News - AI-Generated Market Intelligence | CrowdVerse',
      '/predictions': 'Predictions - Community Consensus | CrowdVerse',
      '/markets': 'Markets - Real-Time Asset Intelligence | CrowdVerse',
      '/portfolio': 'Portfolio - Track Your Investments | CrowdVerse',
      '/early-access': 'Get Early Access - Join CrowdVerse',
    };

    if (location.pathname.startsWith('/asset/')) {
      const symbol = location.pathname.split('/').pop();
      document.title = `${symbol?.toUpperCase()} - Asset Intelligence | CrowdVerse`;
    } else {
      document.title = titles[location.pathname] || 'CrowdVerse - AI-Powered Community Intelligence';
    }
  }, [location]);

  return null;
}

function App() {
  return (
    <Router>
      <TitleUpdater />
      <div className="min-h-screen bg-cv-black font-inter text-cv-off-white relative">
        {/* Grain overlay */}
        <div className="grain-overlay" />
        
        <Navbar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/news" element={<News />} />
            <Route path="/predictions" element={<Predictions />} />
            <Route path="/markets" element={<Markets />} />
            <Route path="/asset/:symbol" element={<Asset />} />
            <Route path="/portfolio" element={<Portfolio />} />
            <Route path="/early-access" element={<EarlyAccess />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
