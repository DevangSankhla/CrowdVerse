import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  BarChart3, 
  Bitcoin, 
  Coins,
  ArrowRight,
  Clock,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

gsap.registerPlugin(ScrollTrigger);

const quickStats = [
  { label: 'NIFTY 50', value: '23,482.85', change: '+1.21%', up: true },
  { label: 'BTC/USD', value: '$67,234.00', change: '+3.29%', up: true },
  { label: 'Crypto Market Cap', value: '$2.85T', change: '+4.2%', up: true },
  { label: 'Market Status', value: 'Live', change: 'Synced', up: true, isLive: true },
];

const stocks = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', price: '₹2,945.30', change: '+1.52%', up: true },
  { symbol: 'TCS', name: 'Tata Consultancy', price: '₹4,123.45', change: '-0.32%', up: false },
  { symbol: 'INFY', name: 'Infosys Ltd', price: '₹1,678.90', change: '+0.89%', up: true },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', price: '₹1,456.70', change: '+0.65%', up: true },
  { symbol: 'ICICIBANK', name: 'ICICI Bank', price: '₹1,234.50', change: '+1.12%', up: true },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel', price: '₹1,123.45', change: '-0.45%', up: false },
];

const crypto = [
  { symbol: 'BTC', name: 'Bitcoin', price: '$67,234.00', change: '+3.29%', up: true },
  { symbol: 'ETH', name: 'Ethereum', price: '$3,456.78', change: '+2.15%', up: true },
  { symbol: 'SOL', name: 'Solana', price: '$145.67', change: '+5.43%', up: true },
  { symbol: 'BNB', name: 'Binance Coin', price: '$567.89', change: '-1.23%', up: false },
  { symbol: 'XRP', name: 'Ripple', price: '$0.67', change: '+0.89%', up: true },
  { symbol: 'ADA', name: 'Cardano', price: '$0.45', change: '-0.34%', up: false },
];

const commodities = [
  { symbol: 'GOLD', name: 'Gold', price: '$2,345.60', change: '-0.45%', up: false },
  { symbol: 'SILVER', name: 'Silver', price: '$27.85', change: '+0.78%', up: true },
  { symbol: 'CRUDEOIL', name: 'Crude Oil', price: '$78.45', change: '+1.23%', up: true },
  { symbol: 'NATURALGAS', name: 'Natural Gas', price: '$2.89', change: '-2.34%', up: false },
  { symbol: 'COPPER', name: 'Copper', price: '$4.12', change: '+0.56%', up: true },
  { symbol: 'ALUMINUM', name: 'Aluminum', price: '$2.34', change: '-0.12%', up: false },
];

function AssetTable({ assets, type }: { assets: typeof stocks; type: string }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/10">
            <th className="text-left py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Asset</th>
            <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Price</th>
            <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Change</th>
            <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Action</th>
          </tr>
        </thead>
        <tbody>
          {assets.map((asset) => (
            <tr 
              key={asset.symbol} 
              className="border-b border-white/5 hover:bg-white/5 transition-colors group"
            >
              <td className="py-4 px-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-cv-dark-gray flex items-center justify-center">
                    {type === 'crypto' ? (
                      <Bitcoin className="w-5 h-5 text-cv-green" />
                    ) : type === 'commodities' ? (
                      <Coins className="w-5 h-5 text-yellow-500" />
                    ) : (
                      <BarChart3 className="w-5 h-5 text-blue-400" />
                    )}
                  </div>
                  <div>
                    <div className="font-semibold text-cv-off-white">{asset.symbol}</div>
                    <div className="text-sm text-cv-light-gray/50">{asset.name}</div>
                  </div>
                </div>
              </td>
              <td className="text-right py-4 px-4 font-medium text-cv-off-white">
                {asset.price}
              </td>
              <td className="text-right py-4 px-4">
                <span className={`inline-flex items-center gap-1 text-sm font-medium ${
                  asset.up ? 'text-green-400' : 'text-red-400'
                }`}>
                  {asset.up ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  {asset.change}
                </span>
              </td>
              <td className="text-right py-4 px-4">
                <Link to={`/asset/${asset.symbol}`}>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-cv-light-gray/70 hover:text-cv-green hover:bg-cv-green/10"
                  >
                    View
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.gsap-fade-up').forEach((el) => {
        gsap.fromTo(
          el,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={sectionRef} className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-10 gsap-fade-up">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="font-space font-bold text-3xl sm:text-4xl md:text-5xl text-cv-off-white mb-2">
                Live Market Overview
              </h1>
              <p className="text-cv-light-gray/70 max-w-xl">
                Real-time data and insights across equities, crypto, and commodities.
              </p>
            </div>
            <div className="flex items-center gap-4 text-sm text-cv-light-gray/50">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                <span>IST</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{currentTime.toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10 gsap-fade-up">
          {quickStats.map((stat, index) => (
            <div
              key={index}
              className="p-5 rounded-xl bg-cv-secondary border border-white/5 hover:border-white/10 transition-colors"
            >
              <div className="text-xs text-cv-light-gray/50 uppercase tracking-wider mb-2">
                {stat.label}
              </div>
              <div className="font-space font-bold text-xl text-cv-off-white mb-1">
                {stat.value}
              </div>
              <div className={`flex items-center gap-1 text-sm ${
                stat.up ? 'text-green-400' : 'text-red-400'
              }`}>
                {stat.isLive ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                    <span>{stat.change}</span>
                  </>
                ) : (
                  <>
                    {stat.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    <span>{stat.change}</span>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Portfolio CTA */}
        <div className="mb-10 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-cv-green/10 to-purple-500/10 border border-cv-green/20 gsap-fade-up">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-5 h-5 text-cv-green" />
                <span className="text-sm text-cv-green font-medium">Portfolio Insights</span>
              </div>
              <h3 className="font-space font-bold text-xl sm:text-2xl text-cv-off-white mb-2">
                Track Your Investments
              </h3>
              <p className="text-cv-light-gray/70 max-w-lg">
                Monitor your portfolio performance, get AI-powered recommendations, and stay on top of your investments.
              </p>
            </div>
            <Link to="/portfolio">
              <Button className="bg-cv-green text-cv-black hover:bg-cv-green-dark font-semibold px-6">
                View Portfolio
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Market Tabs */}
        <div className="gsap-fade-up">
          <Tabs defaultValue="stocks" className="w-full">
            <TabsList className="w-full sm:w-auto bg-cv-secondary border border-white/5 p-1 mb-6">
              <TabsTrigger 
                value="stocks" 
                className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
              >
                Stocks
              </TabsTrigger>
              <TabsTrigger 
                value="crypto"
                className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
              >
                Crypto
              </TabsTrigger>
              <TabsTrigger 
                value="commodities"
                className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
              >
                Commodities
              </TabsTrigger>
            </TabsList>

            <TabsContent value="stocks">
              <div className="rounded-2xl bg-cv-secondary border border-white/5 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-space font-bold text-xl text-cv-off-white">Top Stocks</h3>
                  <Link to="/markets">
                    <Button variant="ghost" size="sm" className="text-cv-green hover:bg-cv-green/10">
                      View All
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                </div>
                <AssetTable assets={stocks} type="stocks" />
              </div>
            </TabsContent>

            <TabsContent value="crypto">
              <div className="rounded-2xl bg-cv-secondary border border-white/5 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-space font-bold text-xl text-cv-off-white">Top Cryptocurrencies</h3>
                  <Link to="/markets">
                    <Button variant="ghost" size="sm" className="text-cv-green hover:bg-cv-green/10">
                      View All
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                </div>
                <AssetTable assets={crypto} type="crypto" />
              </div>
            </TabsContent>

            <TabsContent value="commodities">
              <div className="rounded-2xl bg-cv-secondary border border-white/5 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-space font-bold text-xl text-cv-off-white">Commodities</h3>
                  <Link to="/markets">
                    <Button variant="ghost" size="sm" className="text-cv-green hover:bg-cv-green/10">
                      View All
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  </Link>
                </div>
                <AssetTable assets={commodities} type="commodities" />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
