import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, TrendingUp, Newspaper, BarChart3, Wallet, Home, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const navLinks = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/dashboard', label: 'Dashboard', icon: TrendingUp },
  { path: '/news', label: 'News', icon: Newspaper },
  { path: '/predictions', label: 'Predictions', icon: Sparkles },
  { path: '/markets', label: 'Markets', icon: BarChart3 },
  { path: '/portfolio', label: 'Portfolio', icon: Wallet },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'py-3'
            : 'py-5'
        }`}
      >
        <div
          className={`mx-auto transition-all duration-500 ${
            isScrolled
              ? 'max-w-4xl px-6 py-3 glass rounded-full mx-4 sm:mx-auto'
              : 'max-w-7xl px-4 sm:px-6 lg:px-8'
          }`}
        >
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded-lg bg-cv-green/10 flex items-center justify-center group-hover:bg-cv-green/20 transition-colors">
                <TrendingUp className="w-5 h-5 text-cv-green" />
              </div>
              <span className="font-space font-bold text-xl tracking-tight">
                Crowd<span className="text-cv-green">Verse</span>
              </span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                    isActive(link.path)
                      ? 'text-cv-green bg-cv-green/10'
                      : 'text-cv-light-gray/70 hover:text-cv-off-white hover:bg-white/5'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden md:block">
              <Link to="/early-access">
                <Button
                  className="bg-cv-green text-cv-black hover:bg-cv-green-dark font-semibold px-5 py-2 rounded-lg transition-all duration-300 hover:shadow-glow"
                >
                  Get Early Access
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-white/5 transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 md:hidden transition-all duration-500 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        <div
          className="absolute inset-0 bg-cv-black/95 backdrop-blur-xl"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        <div
          className={`absolute top-20 left-4 right-4 glass rounded-2xl p-6 transition-all duration-500 ${
            isMobileMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-10 opacity-0'
          }`}
        >
          <div className="flex flex-col gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    isActive(link.path)
                      ? 'text-cv-green bg-cv-green/10'
                      : 'text-cv-light-gray/70 hover:text-cv-off-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{link.label}</span>
                </Link>
              );
            })}
            <div className="pt-4 mt-2 border-t border-white/10">
              <Link to="/early-access" className="block">
                <Button
                  className="w-full bg-cv-green text-cv-black hover:bg-cv-green-dark font-semibold py-3 rounded-xl"
                >
                  Get Early Access
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
