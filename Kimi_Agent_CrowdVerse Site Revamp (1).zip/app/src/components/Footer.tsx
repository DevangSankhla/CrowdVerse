import { Link } from 'react-router-dom';
import { TrendingUp, Twitter, Linkedin, Github, Mail, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const footerLinks = {
  product: [
    { label: 'Dashboard', path: '/dashboard' },
    { label: 'News', path: '/news' },
    { label: 'Predictions', path: '/predictions' },
    { label: 'Markets', path: '/markets' },
    { label: 'Portfolio', path: '/portfolio' },
  ],
  company: [
    { label: 'About Us', path: '#' },
    { label: 'Careers', path: '#' },
    { label: 'Blog', path: '#' },
    { label: 'Press Kit', path: '#' },
  ],
  legal: [
    { label: 'Privacy Policy', path: '#' },
    { label: 'Terms of Service', path: '#' },
    { label: 'Cookie Policy', path: '#' },
  ],
};

const socialLinks = [
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Mail, href: 'mailto:hello@crowdverse.in', label: 'Email' },
];

export default function Footer() {
  return (
    <footer className="bg-cv-secondary border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Brand & Newsletter */}
          <div className="lg:col-span-5 space-y-6">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-cv-green/10 flex items-center justify-center group-hover:bg-cv-green/20 transition-colors">
                <TrendingUp className="w-6 h-6 text-cv-green" />
              </div>
              <span className="font-space font-bold text-2xl tracking-tight">
                Crowd<span className="text-cv-green">Verse</span>
              </span>
            </Link>
            <p className="text-cv-light-gray/70 max-w-sm leading-relaxed">
              India's First AI Forward Community Intelligence Platform. 
              Track markets, predict trends, and make informed decisions with real-time crowd sentiment.
            </p>
            
            {/* Newsletter */}
            <div className="space-y-3">
              <h4 className="font-semibold text-sm uppercase tracking-wider text-cv-light-gray/50">
                Stay Updated
              </h4>
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-cv-black border-white/10 focus:border-cv-green/50 text-cv-off-white placeholder:text-cv-light-gray/40"
                />
                <Button className="bg-cv-green text-cv-black hover:bg-cv-green-dark px-4">
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>

          {/* Links */}
          <div className="lg:col-span-7">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-8">
              {/* Product */}
              <div className="space-y-4">
                <h4 className="font-semibold text-sm uppercase tracking-wider text-cv-light-gray/50">
                  Product
                </h4>
                <ul className="space-y-3">
                  {footerLinks.product.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.path}
                        className="text-cv-light-gray/70 hover:text-cv-green transition-colors duration-300"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Company */}
              <div className="space-y-4">
                <h4 className="font-semibold text-sm uppercase tracking-wider text-cv-light-gray/50">
                  Company
                </h4>
                <ul className="space-y-3">
                  {footerLinks.company.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.path}
                        className="text-cv-light-gray/70 hover:text-cv-green transition-colors duration-300"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Legal */}
              <div className="space-y-4">
                <h4 className="font-semibold text-sm uppercase tracking-wider text-cv-light-gray/50">
                  Legal
                </h4>
                <ul className="space-y-3">
                  {footerLinks.legal.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.path}
                        className="text-cv-light-gray/70 hover:text-cv-green transition-colors duration-300"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-cv-light-gray/50 text-sm">
            © 2025 CrowdVerse. All rights reserved.
          </p>
          
          {/* Social Links */}
          <div className="flex items-center gap-3">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-cv-light-gray/70 hover:text-cv-green hover:bg-cv-green/10 transition-all duration-300"
                  aria-label={social.label}
                >
                  <Icon className="w-5 h-5" />
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </footer>
  );
}
