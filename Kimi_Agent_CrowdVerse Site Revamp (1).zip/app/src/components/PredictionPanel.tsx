import { useState } from 'react';
import { ChevronDown, ChevronUp, TrendingUp, Users, Clock, BarChart3 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import CommentSection from './CommentSection';
import AIIntelligencePanel from './AIIntelligencePanel';

interface PredictionOption {
  id: string;
  label: string;
  percentage: number;
  votes: number;
}

interface Prediction {
  id: string;
  question: string;
  category: string;
  totalVotes: number;
  endsIn: string;
  trending: boolean;
  options: PredictionOption[];
  aiSections: {
    title: string;
    icon: string;
    content: string;
  }[];
  comments: {
    id: string;
    author: string;
    content: string;
    timestamp: string;
    likes: number;
    replies: any[];
  }[];
}

interface PredictionPanelProps {
  prediction: Prediction;
}

export default function PredictionPanel({ prediction }: PredictionPanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleVote = (optionId: string) => {
    setSelectedOption(optionId);
    setHasVoted(true);
  };

  const totalVotesFormatted = prediction.totalVotes.toLocaleString();

  return (
    <div className="rounded-2xl bg-cv-secondary border border-white/5 overflow-hidden transition-all duration-300 hover:border-white/10">
      {/* Header - Always visible */}
      <div 
        className="p-5 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            {/* Meta */}
            <div className="flex items-center gap-3 mb-3">
              <Badge variant="outline" className="bg-purple-500/10 border-purple-500/20 text-purple-400 text-xs">
                {prediction.category}
              </Badge>
              {prediction.trending && (
                <Badge variant="outline" className="bg-orange-500/10 border-orange-500/20 text-orange-400 text-xs flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  Trending
                </Badge>
              )}
              <div className="flex items-center gap-1 text-xs text-cv-light-gray/50">
                <Clock className="w-3 h-3" />
                <span>Ends in {prediction.endsIn}</span>
              </div>
            </div>

            {/* Question */}
            <h3 className="font-space font-semibold text-lg text-cv-off-white mb-2">
              {prediction.question}
            </h3>

            {/* Stats */}
            <div className="flex items-center gap-4 text-sm text-cv-light-gray/50">
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span>{totalVotesFormatted} votes</span>
              </div>
              <div className="flex items-center gap-1">
                <BarChart3 className="w-4 h-4" />
                <span>{prediction.options.length} options</span>
              </div>
            </div>
          </div>

          {/* Expand Icon */}
          <button className="p-2 rounded-lg hover:bg-white/5 transition-colors flex-shrink-0">
            {isExpanded ? (
              <ChevronUp className="w-5 h-5 text-cv-light-gray/50" />
            ) : (
              <ChevronDown className="w-5 h-5 text-cv-light-gray/50" />
            )}
          </button>
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="px-5 pb-5 border-t border-white/5">
          {/* Voting Section */}
          <div className="py-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-medium text-cv-light-gray/70">Community Consensus</h4>
              <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">
                {totalVotesFormatted} VOTES
              </Badge>
            </div>

            {!hasVoted ? (
              // Voting Buttons
              <div className="flex flex-wrap gap-2 mb-4">
                {prediction.options.map((option) => (
                  <Button
                    key={option.id}
                    variant="outline"
                    onClick={() => handleVote(option.id)}
                    className="flex-1 min-w-[120px] border-white/10 text-cv-light-gray/70 hover:bg-purple-500/10 hover:border-purple-500/30 hover:text-purple-400 transition-all"
                  >
                    {option.label}
                  </Button>
                ))}
              </div>
            ) : (
              // Results
              <div className="space-y-3">
                {prediction.options.map((option) => (
                  <div key={option.id}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className={`${selectedOption === option.id ? 'text-purple-400' : 'text-cv-light-gray/70'}`}>
                        {option.label}
                        {selectedOption === option.id && ' ✓'}
                      </span>
                      <span className="text-cv-light-gray/70">{option.percentage}%</span>
                    </div>
                    <div className="h-2 bg-cv-dark-gray rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          selectedOption === option.id 
                            ? 'bg-purple-500' 
                            : 'bg-cv-light-gray/30'
                        }`}
                        style={{ width: `${option.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* AI Intelligence Panel */}
          <AIIntelligencePanel 
            sections={prediction.aiSections}
            sentiment="neutral"
          />

          {/* Comments Section */}
          <CommentSection 
            comments={prediction.comments}
            onAddComment={(content) => console.log('New comment:', content)}
          />
        </div>
      )}
    </div>
  );
}
