import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Sparkles, 
  TrendingUp, 
  Users, 
  BarChart3,
  Search,
  Filter
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import PredictionPanel from '@/components/PredictionPanel';

gsap.registerPlugin(ScrollTrigger);

// Comprehensive predictions data matching the old website
const predictionsData = [
  {
    id: 'PRED-ACT015',
    question: 'Does India need a GenZ protest like Nepal?',
    category: 'Politics',
    totalVotes: 2347,
    endsIn: '14 days',
    trending: true,
    options: [
      { id: 'opt1', label: 'yes, soon in 2026', percentage: 55.6, votes: 1305 },
      { id: 'opt2', label: 'yes, but not right now', percentage: 5.5, votes: 129 },
      { id: 'opt3', label: "maybe, if the government doesn't listen", percentage: 15.4, votes: 361 },
      { id: 'opt4', label: 'No, Modi government is perfect', percentage: 23.3, votes: 547 },
    ],
    aiSections: [
      {
        title: "Global News Summary",
        icon: "●",
        content: "Political analysts draw parallels between the recent youth-led movements in neighbor nations and the rising digital activism in India. Unemployment and educational reforms remain the primary triggers for student mobilization."
      },
      {
        title: "Community Comments Summary",
        icon: "●",
        content: "Social media is home to a growing 'youth-first' political discourse. While some call for structural disruption, others argue that existing democratic channels are sufficient for grievance redressal."
      },
      {
        title: "Market Sentiment Summary",
        icon: "●",
        content: "Internal surveys suggest that 55% of GenZ respondents feel a disconnect with traditional political party machinery, favoring issue-based mobilizations (e.g., Agnipath, Farmers). The stability of policy..."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "A massive singular 'uprising' is less likely than localized, issue-based movements. The stability of policy implementation and government responsiveness will be key determinants in whether youth dissatisfaction translates into street protests."
      }
    ],
    comments: [
      {
        id: 'c1',
        author: 'shreya',
        content: 'we must.. if the govt keeps to keep increasing taxes',
        timestamp: '1/30/2025, 5:09:00 PM',
        likes: 23,
        replies: [
          {
            id: 'c1r1',
            author: 'tax_payer',
            content: 'Taxes are necessary for development. We need better governance, not protests.',
            timestamp: '1/30/2025, 5:30:00 PM',
            likes: 12,
            replies: []
          }
        ]
      },
      {
        id: 'c2',
        author: 'youth_voice',
        content: 'The youth needs better representation. Our concerns are not being heard.',
        timestamp: '1/30/2025, 6:00:00 PM',
        likes: 45,
        replies: []
      },
      {
        id: 'c3',
        author: 'democracy_lover',
        content: 'Protests are a democratic right but should be peaceful and constructive.',
        timestamp: '1/30/2025, 6:30:00 PM',
        likes: 18,
        replies: []
      }
    ]
  },
  {
    id: 'PRED-ACT014',
    question: 'Will SpaceX land humans on Mars by 2026?',
    category: 'Technology',
    totalVotes: 15678,
    endsIn: '365 days',
    trending: true,
    options: [
      { id: 'opt1', label: 'Yes, definitely', percentage: 18.2, votes: 2853 },
      { id: 'opt2', label: 'Maybe, if delays are minimal', percentage: 32.4, votes: 5080 },
      { id: 'opt3', label: 'Unlikely, too ambitious', percentage: 38.7, votes: 6067 },
      { id: 'opt4', label: 'No, impossible timeline', percentage: 10.7, votes: 1678 },
    ],
    aiSections: [
      {
        title: "Technical Feasibility",
        icon: "●",
        content: "SpaceX's Starship program has made significant progress but faces critical challenges in life support systems, radiation shielding, and in-situ resource utilization. The 2026 timeline is aggressive even by Musk's standards."
      },
      {
        title: "Funding & Political Will",
        icon: "●",
        content: "NASA contracts provide partial funding, but Mars mission costs exceed $100B. Political support remains strong but could shift with administration changes. Private investment is growing but insufficient."
      },
      {
        title: "Historical Precedents",
        icon: "●",
        content: "Apollo program took 8 years from announcement to moon landing. Mars is exponentially more complex. Previous Mars mission timelines have consistently slipped by 5-10 years."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "While SpaceX has defied skeptics before, the 2026 Mars landing target appears unrealistic. A more probable timeline is 2028-2030 for an orbital mission, with surface landing by 2032-2035."
      }
    ],
    comments: [
      {
        id: 'c4',
        author: 'space_enthusiast',
        content: 'Elon has proven everyone wrong before. Never underestimate SpaceX!',
        timestamp: '1/30/2025, 2:00:00 PM',
        likes: 89,
        replies: []
      },
      {
        id: 'c5',
        author: 'realist_engineer',
        content: '2026 is way too optimistic. Life support alone needs 5+ years of testing.',
        timestamp: '1/30/2025, 2:30:00 PM',
        likes: 67,
        replies: [
          {
            id: 'c5r1',
            author: 'musk_fan',
            content: 'They\'ve been working on this for years. The tech is almost ready.',
            timestamp: '1/30/2025, 3:00:00 PM',
            likes: 23,
            replies: []
          }
        ]
      }
    ]
  },
  {
    id: 'PRED-ACT013',
    question: 'Will NIFTY 50 cross 25,000 by end of 2025?',
    category: 'Markets',
    totalVotes: 8921,
    endsIn: '180 days',
    trending: true,
    options: [
      { id: 'opt1', label: 'Yes, easily', percentage: 42.3, votes: 3774 },
      { id: 'opt2', label: 'Yes, but barely', percentage: 25.7, votes: 2293 },
      { id: 'opt3', label: 'No, will fall short', percentage: 22.1, votes: 1972 },
      { id: 'opt4', label: 'No, market will crash', percentage: 9.9, votes: 883 },
    ],
    aiSections: [
      {
        title: "Market Fundamentals",
        icon: "●",
        content: "Corporate earnings growth at 12-15% YoY supports bullish case. GDP growth projections of 6.5-7% provide macro tailwinds. FII flows have turned positive after 2 years of outflows."
      },
      {
        title: "Technical Analysis",
        icon: "●",
        content: "NIFTY needs 6.7% upside from current levels. Historical data shows 8-10% annual returns. 25K is achievable if current momentum continues. Support at 23,000, resistance at 24,500."
      },
      {
        title: "Risk Factors",
        icon: "●",
        content: "Geopolitical tensions in Middle East could spike oil prices. US Fed policy uncertainty. Domestic inflation remains sticky at 5%+. Valuations at 22x PE are above historical averages."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "Probability of NIFTY crossing 25K in 2025 is 68%. Key monitorables: Q4 earnings, monsoon performance, and global liquidity conditions. Accumulate on dips strategy recommended."
      }
    ],
    comments: [
      {
        id: 'c6',
        author: 'bullish_investor',
        content: '25K is conservative. We might see 26-27K if flows continue!',
        timestamp: '1/30/2025, 10:00:00 AM',
        likes: 34,
        replies: []
      },
      {
        id: 'c7',
        author: 'bearish_view',
        content: 'Valuations are stretched. Correction is overdue.',
        timestamp: '1/30/2025, 10:30:00 AM',
        likes: 28,
        replies: [
          {
            id: 'c7r1',
            author: 'long_term',
            content: 'Short term volatility is normal. India growth story is intact.',
            timestamp: '1/30/2025, 11:00:00 AM',
            likes: 19,
            replies: []
          }
        ]
      }
    ]
  },
  {
    id: 'PRED-ACT012',
    question: 'Will Bitcoin reach $100,000 this year?',
    category: 'Crypto',
    totalVotes: 45678,
    endsIn: '240 days',
    trending: true,
    options: [
      { id: 'opt1', label: 'Yes, before June', percentage: 15.2, votes: 6943 },
      { id: 'opt2', label: 'Yes, by year-end', percentage: 38.7, votes: 17677 },
      { id: 'opt3', label: 'No, will stay below', percentage: 31.4, votes: 14343 },
      { id: 'opt4', label: 'No, crypto winter returns', percentage: 14.7, votes: 6715 },
    ],
    aiSections: [
      {
        title: "Institutional Flows",
        icon: "●",
        content: "ETF inflows averaging $500M daily. MicroStrategy and Tesla adding to positions. Pension funds beginning 1-2% allocations. Corporate treasury adoption accelerating."
      },
      {
        title: "Supply Dynamics",
        icon: "●",
        content: "Post-halving supply shock kicking in. Miner selling pressure reduced. 70% of supply hasn't moved in 1+ years. Exchange balances at 5-year lows."
      },
      {
        title: "Macro Environment",
        icon: "●",
        content: "Fed rate cuts expected in 2025. Dollar weakness historically bullish for BTC. Gold making new highs - BTC following correlation. Inflation hedge narrative strengthening."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "$100K Bitcoin in 2025 has 72% probability. Most likely scenario: Q2-Q3 rally to $95-105K range. Key catalysts: ETF flows, halving effects, and regulatory clarity."
      }
    ],
    comments: [
      {
        id: 'c8',
        author: 'btc_maximalist',
        content: '100K is FUD. We\'re going to 150K+ this cycle!',
        timestamp: '1/30/2025, 8:00:00 AM',
        likes: 156,
        replies: []
      },
      {
        id: 'c9',
        author: 'skeptic_trader',
        content: 'Every cycle people say this. Remember 2021?',
        timestamp: '1/30/2025, 8:30:00 AM',
        likes: 89,
        replies: [
          {
            id: 'c9r1',
            author: 'hodl_gang',
            content: 'This time is different. Institutions are here.',
            timestamp: '1/30/2025, 9:00:00 AM',
            likes: 67,
            replies: []
          }
        ]
      }
    ]
  },
  {
    id: 'PRED-ACT011',
    question: 'Will India win the ICC World Cup 2027?',
    category: 'Sports',
    totalVotes: 12345,
    endsIn: '720 days',
    trending: false,
    options: [
      { id: 'opt1', label: 'Yes, definitely', percentage: 52.3, votes: 6457 },
      { id: 'opt2', label: 'Maybe, strong chance', percentage: 28.7, votes: 3543 },
      { id: 'opt3', label: 'Unlikely', percentage: 14.2, votes: 1753 },
      { id: 'opt4', label: 'No, other teams stronger', percentage: 4.8, votes: 592 },
    ],
    aiSections: [
      {
        title: "Team Strength Analysis",
        icon: "●",
        content: "India has the deepest talent pool in world cricket. IPL provides unmatched preparation. Bowling attack among world's best. Batting lineup has depth till #8."
      },
      {
        title: "Home Advantage",
        icon: "●",
        content: "2027 WC hosted in India - massive advantage. Familiar conditions, crowd support, and no travel fatigue. Last home WC win was 2011. History favors hosts."
      },
      {
        title: "Competition Analysis",
        icon: "●",
        content: "Australia remains strongest competitor. England's white-ball revolution continues. Pakistan unpredictable but dangerous. New Zealand consistently reaches knockouts."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "India has 55% probability of winning 2027 WC. Home advantage + squad depth = favorites tag justified. Key concern: handling knockout pressure."
      }
    ],
    comments: [
      {
        id: 'c10',
        author: 'cricket_fanatic',
        content: 'Rohit Sharma will lead us to glory!',
        timestamp: '1/29/2025, 6:00:00 PM',
        likes: 234,
        replies: []
      }
    ]
  },
  {
    id: 'PRED-ACT010',
    question: 'Will AI replace 50% of software jobs by 2030?',
    category: 'Technology',
    totalVotes: 32109,
    endsIn: '1800 days',
    trending: true,
    options: [
      { id: 'opt1', label: 'Yes, definitely', percentage: 28.4, votes: 9119 },
      { id: 'opt2', label: 'Yes, but roles will evolve', percentage: 41.2, votes: 13229 },
      { id: 'opt3', label: 'No, AI will augment not replace', percentage: 24.1, votes: 7738 },
      { id: 'opt4', label: 'No, software jobs will grow', percentage: 6.3, votes: 2023 },
    ],
    aiSections: [
      {
        title: "Current AI Capabilities",
        icon: "●",
        content: "GPT-5 and Claude 4 can write production code. Copilot increases developer productivity 30-50%. Automated testing and debugging improving rapidly. Junior dev roles most at risk."
      },
      {
        title: "Industry Adaptation",
        icon: "●",
        content: "Companies hiring fewer entry-level developers. Senior devs becoming AI operators. New roles emerging: AI trainers, prompt engineers, AI ethicists. Total tech employment still growing."
      },
      {
        title: "Historical Precedents",
        icon: "●",
        content: "Automation has always displaced jobs but created new ones. ATM rollout increased banking jobs. Cloud computing created more IT roles. AI likely follows similar pattern."
      },
      {
        title: "Final AI Takeaway",
        icon: "●",
        content: "50% job replacement by 2030 is exaggerated. 30-40% of tasks will be automated, but total software jobs may still grow 10-15%. Upskilling in AI tools is essential for survival."
      }
    ],
    comments: [
      {
        id: 'c11',
        author: 'dev_scared',
        content: 'I\'m already seeing companies hire fewer juniors. This is real.',
        timestamp: '1/29/2025, 4:00:00 PM',
        likes: 145,
        replies: []
      },
      {
        id: 'c12',
        author: 'ai_enthusiast',
        content: 'AI makes good developers 10x more productive. The demand will only increase.',
        timestamp: '1/29/2025, 4:30:00 PM',
        likes: 198,
        replies: [
          {
            id: 'c12r1',
            author: 'senior_dev',
            content: 'Exactly. Focus on architecture and problem solving. AI can\'t replace that.',
            timestamp: '1/29/2025, 5:00:00 PM',
            likes: 87,
            replies: []
          }
        ]
      }
    ]
  }
];

const categories = ['All', 'Politics', 'Technology', 'Markets', 'Crypto', 'Sports'];

export default function Predictions() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const sectionRef = useRef<HTMLDivElement>(null);

  const filteredPredictions = predictionsData.filter((prediction) => {
    const matchesCategory = selectedCategory === 'All' || prediction.category === selectedCategory;
    const matchesSearch = 
      prediction.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prediction.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.gsap-prediction').forEach((el, i) => {
        gsap.fromTo(
          el,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, [filteredPredictions]);

  return (
    <div ref={sectionRef} className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="text-xs text-purple-400 uppercase tracking-wider font-medium">Community Consensus</div>
              <h1 className="font-space font-bold text-3xl sm:text-4xl text-cv-off-white">
                What&apos;s the Verdict?
              </h1>
            </div>
          </div>
          <p className="text-cv-light-gray/70 max-w-2xl">
            Join thousands of participants in predicting the future of tech, finance, and global markets using our crowd-intelligence engine.
          </p>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: 'Active Predictions', value: '24', icon: Sparkles },
            { label: 'Total Votes', value: '142K+', icon: Users },
            { label: 'Accuracy Rate', value: '73%', icon: TrendingUp },
            { label: 'This Week', value: '12K', icon: BarChart3 },
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="p-4 rounded-xl bg-cv-secondary border border-white/5">
                <div className="flex items-center gap-2 mb-2">
                  <Icon className="w-4 h-4 text-cv-light-gray/50" />
                  <span className="text-xs text-cv-light-gray/50 uppercase tracking-wider">{stat.label}</span>
                </div>
                <div className="font-space font-bold text-2xl text-cv-off-white">{stat.value}</div>
              </div>
            );
          })}
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cv-light-gray/50" />
            <Input
              type="text"
              placeholder="Search predictions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-cv-secondary border-white/10 text-cv-off-white placeholder:text-cv-light-gray/40"
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0">
            <Filter className="w-5 h-5 text-cv-light-gray/50 flex-shrink-0" />
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={`flex-shrink-0 ${
                  selectedCategory === category
                    ? 'bg-purple-500 text-white hover:bg-purple-600'
                    : 'border-white/10 text-cv-light-gray/70 hover:bg-white/5 hover:text-cv-off-white'
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Predictions Feed */}
        <div className="space-y-4">
          {filteredPredictions.map((prediction) => (
            <div key={prediction.id} className="gsap-prediction">
              <PredictionPanel prediction={prediction} />
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredPredictions.length === 0 && (
          <div className="text-center py-20">
            <Sparkles className="w-16 h-16 text-cv-light-gray/30 mx-auto mb-4" />
            <h3 className="font-space font-semibold text-xl text-cv-off-white mb-2">
              No predictions found
            </h3>
            <p className="text-cv-light-gray/50">
              Try selecting a different category
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
