import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Search,
  Filter,
  Star,
  Activity,
  Bitcoin,
  Coins,
  Gem
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';

gsap.registerPlugin(ScrollTrigger);

interface Asset {
  symbol: string;
  name: string;
  price: string;
  change: string;
  up: boolean;
  volume: string;
  marketCap: string;
  aiSentiment: 'bullish' | 'bearish' | 'neutral';
  aiScore: number;
}

const stocksData: Asset[] = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', price: '₹2,945.30', change: '+1.52%', up: true, volume: '8.2M', marketCap: '₹19.8T', aiSentiment: 'bullish', aiScore: 78 },
  { symbol: 'TCS', name: 'Tata Consultancy', price: '₹4,123.45', change: '-0.32%', up: false, volume: '2.1M', marketCap: '₹15.2T', aiSentiment: 'neutral', aiScore: 52 },
  { symbol: 'INFY', name: 'Infosys Ltd', price: '₹1,678.90', change: '+0.89%', up: true, volume: '4.5M', marketCap: '₹6.9T', aiSentiment: 'bullish', aiScore: 71 },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', price: '₹1,456.70', change: '+0.65%', up: true, volume: '5.8M', marketCap: '₹11.2T', aiSentiment: 'bullish', aiScore: 82 },
  { symbol: 'ICICIBANK', name: 'ICICI Bank', price: '₹1,234.50', change: '+1.12%', up: true, volume: '6.2M', marketCap: '₹8.7T', aiSentiment: 'bullish', aiScore: 75 },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel', price: '₹1,123.45', change: '-0.45%', up: false, volume: '3.1M', marketCap: '₹6.3T', aiSentiment: 'neutral', aiScore: 48 },
  { symbol: 'ITC', name: 'ITC Limited', price: '₹432.50', change: '+0.78%', up: true, volume: '7.5M', marketCap: '₹5.4T', aiSentiment: 'bullish', aiScore: 68 },
  { symbol: 'SBIN', name: 'State Bank of India', price: '₹756.80', change: '-0.23%', up: false, volume: '9.1M', marketCap: '₹6.8T', aiSentiment: 'neutral', aiScore: 55 },
];

const cryptoData: Asset[] = [
  { symbol: 'BTC', name: 'Bitcoin', price: '$67,234.00', change: '+3.29%', up: true, volume: '$32.5B', marketCap: '$1.32T', aiSentiment: 'bullish', aiScore: 85 },
  { symbol: 'ETH', name: 'Ethereum', price: '$3,456.78', change: '+2.15%', up: true, volume: '$18.2B', marketCap: '$415B', aiSentiment: 'bullish', aiScore: 79 },
  { symbol: 'SOL', name: 'Solana', price: '$145.67', change: '+5.43%', up: true, volume: '$4.8B', marketCap: '$65B', aiSentiment: 'bullish', aiScore: 88 },
  { symbol: 'BNB', name: 'Binance Coin', price: '$567.89', change: '-1.23%', up: false, volume: '$1.2B', marketCap: '$85B', aiSentiment: 'neutral', aiScore: 45 },
  { symbol: 'XRP', name: 'Ripple', price: '$0.67', change: '+0.89%', up: true, volume: '$2.1B', marketCap: '$37B', aiSentiment: 'neutral', aiScore: 52 },
  { symbol: 'ADA', name: 'Cardano', price: '$0.45', change: '-0.34%', up: false, volume: '$890M', marketCap: '$16B', aiSentiment: 'bearish', aiScore: 38 },
];

const commoditiesData: Asset[] = [
  { symbol: 'GOLD', name: 'Gold', price: '$2,345.60', change: '-0.45%', up: false, volume: '125K', marketCap: 'N/A', aiSentiment: 'neutral', aiScore: 50 },
  { symbol: 'SILVER', name: 'Silver', price: '$27.85', change: '+0.78%', up: true, volume: '89K', marketCap: 'N/A', aiSentiment: 'bullish', aiScore: 62 },
  { symbol: 'CRUDEOIL', name: 'Crude Oil', price: '$78.45', change: '+1.23%', up: true, volume: '450K', marketCap: 'N/A', aiSentiment: 'bullish', aiScore: 71 },
  { symbol: 'NATURALGAS', name: 'Natural Gas', price: '$2.89', change: '-2.34%', up: false, volume: '234K', marketCap: 'N/A', aiSentiment: 'bearish', aiScore: 35 },
  { symbol: 'COPPER', name: 'Copper', price: '$4.12', change: '+0.56%', up: true, volume: '67K', marketCap: 'N/A', aiSentiment: 'bullish', aiScore: 68 },
  { symbol: 'ALUMINUM', name: 'Aluminum', price: '$2.34', change: '-0.12%', up: false, volume: '45K', marketCap: 'N/A', aiSentiment: 'neutral', aiScore: 48 },
];

function getSentimentColor(sentiment: string) {
  switch (sentiment) {
    case 'bullish':
      return 'text-green-400 bg-green-500/10 border-green-500/20';
    case 'bearish':
      return 'text-red-400 bg-red-500/10 border-red-500/20';
    default:
      return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
  }
}

function getScoreColor(score: number) {
  if (score >= 70) return 'text-green-400';
  if (score >= 40) return 'text-yellow-400';
  return 'text-red-400';
}

function AssetCard({ asset, type }: { asset: Asset; type: string }) {
  return (
    <Link to={`/asset/${asset.symbol}`}>
      <div className="group p-5 rounded-xl bg-cv-secondary border border-white/5 
        hover:border-cv-green/30 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cv-dark-gray flex items-center justify-center">
              {type === 'crypto' ? (
                <Bitcoin className="w-5 h-5 text-cv-green" />
              ) : type === 'commodities' ? (
                <Coins className="w-5 h-5 text-yellow-500" />
              ) : (
                <BarChart3 className="w-5 h-5 text-blue-400" />
              )}
            </div>
            <div>
              <div className="font-semibold text-cv-off-white">{asset.symbol}</div>
              <div className="text-xs text-cv-light-gray/50">{asset.name}</div>
            </div>
          </div>
          <button className="p-2 rounded-lg hover:bg-white/5 transition-colors">
            <Star className="w-4 h-4 text-cv-light-gray/50 hover:text-cv-green" />
          </button>
        </div>

        {/* Price */}
        <div className="mb-4">
          <div className="font-space font-bold text-2xl text-cv-off-white mb-1">
            {asset.price}
          </div>
          <div className={`flex items-center gap-1 text-sm ${asset.up ? 'text-green-400' : 'text-red-400'}`}>
            {asset.up ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span>{asset.change}</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
          <div>
            <div className="text-cv-light-gray/50 text-xs mb-1">Volume</div>
            <div className="text-cv-off-white">{asset.volume}</div>
          </div>
          <div>
            <div className="text-cv-light-gray/50 text-xs mb-1">Market Cap</div>
            <div className="text-cv-off-white">{asset.marketCap}</div>
          </div>
        </div>

        {/* AI Sentiment */}
        <div className="pt-4 border-t border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-cv-light-gray/50" />
              <span className="text-xs text-cv-light-gray/50">AI Sentiment</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={`text-xs capitalize ${getSentimentColor(asset.aiSentiment)}`}>
                {asset.aiSentiment}
              </Badge>
              <span className={`font-semibold text-sm ${getScoreColor(asset.aiScore)}`}>
                {asset.aiScore}
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

export default function Markets() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('stocks');
  const sectionRef = useRef<HTMLDivElement>(null);

  const filterAssets = (assets: Asset[]) => {
    return assets.filter(
      (asset) =>
        asset.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        asset.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  };

  const filteredStocks = filterAssets(stocksData);
  const filteredCrypto = filterAssets(cryptoData);
  const filteredCommodities = filterAssets(commoditiesData);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.gsap-asset-card').forEach((el, i) => {
        gsap.fromTo(
          el,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.5,
            delay: i * 0.05,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 95%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, [filteredStocks, filteredCrypto, filteredCommodities, activeTab]);

  return (
    <div ref={sectionRef} className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-cv-green/10 border border-cv-green/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-cv-green" />
            </div>
            <div>
              <div className="text-xs text-cv-green uppercase tracking-wider font-medium">Real-Time Data</div>
              <h1 className="font-space font-bold text-3xl sm:text-4xl text-cv-off-white">
                Markets
              </h1>
            </div>
          </div>
          <p className="text-cv-light-gray/70 max-w-2xl">
            Track stocks, crypto, and commodities with live prices, AI sentiment analysis, and market insights.
          </p>
        </div>

        {/* Search */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-cv-light-gray/50" />
            <Input
              type="text"
              placeholder="Search assets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-cv-secondary border-white/10 text-cv-off-white placeholder:text-cv-light-gray/40"
            />
          </div>
          <Button variant="outline" className="border-white/10 text-cv-light-gray/70 hover:bg-white/5">
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="stocks" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="w-full sm:w-auto bg-cv-secondary border border-white/5 p-1 mb-8">
            <TabsTrigger 
              value="stocks" 
              className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Stocks
            </TabsTrigger>
            <TabsTrigger 
              value="crypto"
              className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
            >
              <Bitcoin className="w-4 h-4 mr-2" />
              Crypto
            </TabsTrigger>
            <TabsTrigger 
              value="commodities"
              className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
            >
              <Gem className="w-4 h-4 mr-2" />
              Commodities
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stocks">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredStocks.map((asset) => (
                <div key={asset.symbol} className="gsap-asset-card">
                  <AssetCard asset={asset} type="stocks" />
                </div>
              ))}
            </div>
            {filteredStocks.length === 0 && (
              <div className="text-center py-20">
                <BarChart3 className="w-16 h-16 text-cv-light-gray/30 mx-auto mb-4" />
                <h3 className="font-space font-semibold text-xl text-cv-off-white mb-2">
                  No stocks found
                </h3>
                <p className="text-cv-light-gray/50">Try adjusting your search</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="crypto">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredCrypto.map((asset) => (
                <div key={asset.symbol} className="gsap-asset-card">
                  <AssetCard asset={asset} type="crypto" />
                </div>
              ))}
            </div>
            {filteredCrypto.length === 0 && (
              <div className="text-center py-20">
                <Bitcoin className="w-16 h-16 text-cv-light-gray/30 mx-auto mb-4" />
                <h3 className="font-space font-semibold text-xl text-cv-off-white mb-2">
                  No crypto found
                </h3>
                <p className="text-cv-light-gray/50">Try adjusting your search</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="commodities">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredCommodities.map((asset) => (
                <div key={asset.symbol} className="gsap-asset-card">
                  <AssetCard asset={asset} type="commodities" />
                </div>
              ))}
            </div>
            {filteredCommodities.length === 0 && (
              <div className="text-center py-20">
                <Gem className="w-16 h-16 text-cv-light-gray/30 mx-auto mb-4" />
                <h3 className="font-space font-semibold text-xl text-cv-off-white mb-2">
                  No commodities found
                </h3>
                <p className="text-cv-light-gray/50">Try adjusting your search</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
