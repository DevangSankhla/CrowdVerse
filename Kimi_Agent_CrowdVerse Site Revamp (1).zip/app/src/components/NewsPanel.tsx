import { useState } from 'react';
import { ChevronDown, ChevronUp, Clock, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import CommentSection from './CommentSection';
import AIIntelligencePanel from './AIIntelligencePanel';

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  category: string;
  timestamp: string;
  readTime: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  image?: string;
  aiSections: {
    title: string;
    icon: string;
    content: string;
  }[];
  comments: {
    id: string;
    author: string;
    content: string;
    timestamp: string;
    likes: number;
    replies: any[];
  }[];
}

interface NewsPanelProps {
  news: NewsItem;
}

const sentimentConfig = {
  positive: { Icon: TrendingUp, color: 'text-green-400 bg-green-500/10 border-green-500/20', label: 'Positive' },
  negative: { Icon: TrendingDown, color: 'text-red-400 bg-red-500/10 border-red-500/20', label: 'Negative' },
  neutral: { Icon: Minus, color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', label: 'Neutral' },
};

export default function NewsPanel({ news }: NewsPanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const sentiment = sentimentConfig[news.sentiment];
  const SentimentIcon = sentiment.Icon;

  return (
    <div className="rounded-2xl bg-cv-secondary border border-white/5 overflow-hidden transition-all duration-300 hover:border-white/10">
      {/* Header - Always visible */}
      <div 
        className="p-5 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            {/* Meta */}
            <div className="flex items-center gap-3 mb-3">
              <Badge variant="outline" className="bg-cv-dark-gray border-white/10 text-cv-light-gray/70 text-xs">
                {news.category}
              </Badge>
              <Badge variant="outline" className={`${sentiment.color} text-xs flex items-center gap-1`}>
                <SentimentIcon className="w-3 h-3" />
                {sentiment.label}
              </Badge>
              <div className="flex items-center gap-1 text-xs text-cv-light-gray/50">
                <Clock className="w-3 h-3" />
                <span>{news.timestamp}</span>
              </div>
            </div>

            {/* Title */}
            <h3 className="font-space font-semibold text-lg text-cv-off-white mb-2 group-hover:text-cv-green transition-colors">
              {news.title}
            </h3>

            {/* Summary */}
            <p className="text-cv-light-gray/70 text-sm leading-relaxed line-clamp-2">
              {news.summary}
            </p>

            {/* Source & Read Time */}
            <div className="flex items-center gap-4 mt-3 text-xs text-cv-light-gray/50">
              <span>{news.source}</span>
              <span>•</span>
              <span>{news.readTime} read</span>
            </div>
          </div>

          {/* Expand Icon */}
          <button className="p-2 rounded-lg hover:bg-white/5 transition-colors flex-shrink-0">
            {isExpanded ? (
              <ChevronUp className="w-5 h-5 text-cv-light-gray/50" />
            ) : (
              <ChevronDown className="w-5 h-5 text-cv-light-gray/50" />
            )}
          </button>
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="px-5 pb-5 border-t border-white/5">
          {/* Full Content */}
          <div className="py-4">
            <p className="text-cv-light-gray/80 text-sm leading-relaxed">
              {news.summary}
            </p>
          </div>

          {/* AI Intelligence Panel */}
          <AIIntelligencePanel 
            sections={news.aiSections}
            sentiment={news.sentiment === 'positive' ? 'bullish' : news.sentiment === 'negative' ? 'bearish' : 'neutral'}
          />

          {/* Comments Section */}
          <CommentSection 
            comments={news.comments}
            onAddComment={(content) => console.log('New comment:', content)}
          />
        </div>
      )}
    </div>
  );
}
