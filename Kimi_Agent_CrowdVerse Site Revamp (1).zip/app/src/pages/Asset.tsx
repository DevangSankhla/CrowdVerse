import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  TrendingUp, 
  TrendingDown, 
  ArrowLeft,
  Activity,
  BarChart3,
  Newspaper,
  Brain,
  Users,
  Share2,
  Star,
  AlertTriangle,
  CheckCircle2,
  XCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

interface AssetData {
  symbol: string;
  name: string;
  price: string;
  change: string;
  up: boolean;
  volume: string;
  marketCap: string;
  dayHigh: string;
  dayLow: string;
  open: string;
  prevClose: string;
  aiSentiment: 'bullish' | 'bearish' | 'neutral';
  aiScore: number;
  aiSummary: string;
  keyPoints: string[];
  news: {
    id: number;
    title: string;
    source: string;
    time: string;
    sentiment: 'positive' | 'negative' | 'neutral';
  }[];
}

const assetDatabase: Record<string, AssetData> = {
  RELIANCE: {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Limited',
    price: '₹2,945.30',
    change: '+1.52%',
    up: true,
    volume: '8.2M',
    marketCap: '₹19.8T',
    dayHigh: '₹2,967.50',
    dayLow: '₹2,901.20',
    open: '₹2,910.00',
    prevClose: '₹2,901.20',
    aiSentiment: 'bullish',
    aiScore: 78,
    aiSummary: 'Reliance Industries shows strong momentum driven by robust performance in retail and digital services segments. Jio\'s subscriber growth and expansion into 5G services provide positive outlook. The company\'s diversification strategy continues to pay off with stable O2C business performance.',
    keyPoints: [
      'Jio subscriber base crossed 450 million',
      'Retail segment showing 15% YoY growth',
      'New energy initiatives gaining traction',
      'Strong cash flow generation continues'
    ],
    news: [
      { id: 1, title: 'Reliance Q3 profit rises 12% to ₹19,641 crore', source: 'Economic Times', time: '6 hours ago', sentiment: 'positive' },
      { id: 2, title: 'Jio adds 5 million subscribers in December', source: 'Business Standard', time: '12 hours ago', sentiment: 'positive' },
      { id: 3, title: 'Reliance Retail expands to 50 new cities', source: 'Mint', time: '1 day ago', sentiment: 'positive' },
    ]
  },
  BTC: {
    symbol: 'BTC',
    name: 'Bitcoin',
    price: '$67,234.00',
    change: '+3.29%',
    up: true,
    volume: '$32.5B',
    marketCap: '$1.32T',
    dayHigh: '$68,450.00',
    dayLow: '$65,120.00',
    open: '$65,200.00',
    prevClose: '$65,100.00',
    aiSentiment: 'bullish',
    aiScore: 85,
    aiSummary: 'Bitcoin is experiencing strong upward momentum driven by record ETF inflows and growing institutional adoption. The breakthrough above $67,000 signals renewed bullish sentiment. Technical indicators suggest potential for further gains if current support levels hold.',
    keyPoints: [
      'ETF inflows exceed $500M daily',
      'Institutional adoption accelerating',
      'Hash rate at all-time highs',
      'Supply dynamics remain favorable'
    ],
    news: [
      { id: 1, title: 'Bitcoin ETF inflows hit record $500M daily', source: 'CoinDesk', time: '4 hours ago', sentiment: 'positive' },
      { id: 2, title: 'MicroStrategy adds 3,000 more Bitcoin', source: 'CryptoSlate', time: '8 hours ago', sentiment: 'positive' },
      { id: 3, title: 'Bitcoin mining difficulty reaches new ATH', source: 'Bitcoin Magazine', time: '12 hours ago', sentiment: 'neutral' },
    ]
  },
};

function SentimentIcon({ sentiment }: { sentiment: string }) {
  switch (sentiment) {
    case 'positive':
      return <CheckCircle2 className="w-4 h-4 text-green-400" />;
    case 'negative':
      return <XCircle className="w-4 h-4 text-red-400" />;
    default:
      return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
  }
}

export default function Asset() {
  const { symbol } = useParams<{ symbol: string }>();
  const [isWatchlisted, setIsWatchlisted] = useState(false);
  
  const asset = symbol ? assetDatabase[symbol.toUpperCase()] : null;

  if (!asset) {
    return (
      <div className="min-h-screen bg-cv-black pt-24 pb-16 flex items-center justify-center">
        <div className="text-center">
          <BarChart3 className="w-16 h-16 text-cv-light-gray/30 mx-auto mb-4" />
          <h2 className="font-space font-bold text-2xl text-cv-off-white mb-2">
            Asset Not Found
          </h2>
          <p className="text-cv-light-gray/50 mb-6">
            We couldn&apos;t find information for {symbol?.toUpperCase()}
          </p>
          <Link to="/markets">
            <Button className="bg-cv-green text-cv-black hover:bg-cv-green-dark">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Markets
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const sentimentColor = asset.aiSentiment === 'bullish' ? 'text-green-400' : 
                        asset.aiSentiment === 'bearish' ? 'text-red-400' : 'text-yellow-400';

  return (
    <div className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link to="/markets" className="inline-flex items-center gap-2 text-cv-light-gray/50 hover:text-cv-green transition-colors mb-6">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Markets</span>
        </Link>

        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 mb-8">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-cv-green/10 border border-cv-green/20 flex items-center justify-center">
              <BarChart3 className="w-8 h-8 text-cv-green" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="font-space font-bold text-3xl text-cv-off-white">{asset.symbol}</h1>
                <Badge variant="outline" className="bg-cv-dark-gray border-white/10 text-cv-light-gray/70">
                  {asset.name}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-sm text-cv-light-gray/50">
                <span>Volume: {asset.volume}</span>
                <span>Market Cap: {asset.marketCap}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="icon"
              className={`border-white/10 ${isWatchlisted ? 'text-cv-green' : 'text-cv-light-gray/50'}`}
              onClick={() => setIsWatchlisted(!isWatchlisted)}
            >
              <Star className={`w-5 h-5 ${isWatchlisted ? 'fill-current' : ''}`} />
            </Button>
            <Button variant="outline" size="icon" className="border-white/10 text-cv-light-gray/50">
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Price Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2 p-6 rounded-2xl bg-cv-secondary border border-white/5">
            <div className="flex items-end gap-4 mb-6">
              <div className="font-space font-bold text-5xl text-cv-off-white">
                {asset.price}
              </div>
              <div className={`flex items-center gap-1 text-lg pb-2 ${asset.up ? 'text-green-400' : 'text-red-400'}`}>
                {asset.up ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                <span>{asset.change}</span>
              </div>
            </div>

            {/* Price Chart Placeholder */}
            <div className="h-64 rounded-xl bg-cv-dark-gray/50 flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="w-12 h-12 text-cv-light-gray/30 mx-auto mb-3" />
                <p className="text-cv-light-gray/50">Interactive chart coming soon</p>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="p-6 rounded-2xl bg-cv-secondary border border-white/5">
            <h3 className="font-semibold text-cv-off-white mb-4">Key Statistics</h3>
            <div className="space-y-4">
              {[
                { label: 'Day High', value: asset.dayHigh },
                { label: 'Day Low', value: asset.dayLow },
                { label: 'Open', value: asset.open },
                { label: 'Previous Close', value: asset.prevClose },
              ].map((stat) => (
                <div key={stat.label} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <span className="text-cv-light-gray/50">{stat.label}</span>
                  <span className="font-medium text-cv-off-white">{stat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Intelligence */}
        <div className="mb-8">
          <Tabs defaultValue="summary" className="w-full">
            <TabsList className="bg-cv-secondary border border-white/5 p-1 mb-6">
              <TabsTrigger 
                value="summary" 
                className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
              >
                <Brain className="w-4 h-4 mr-2" />
                AI Summary
              </TabsTrigger>
              <TabsTrigger 
                value="news"
                className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
              >
                <Newspaper className="w-4 h-4 mr-2" />
                News
              </TabsTrigger>
              <TabsTrigger 
                value="sentiment"
                className="data-[state=active]:bg-cv-off-white data-[state=active]:text-cv-black"
              >
                <Activity className="w-4 h-4 mr-2" />
                Sentiment
              </TabsTrigger>
            </TabsList>

            <TabsContent value="summary">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 p-6 rounded-2xl bg-cv-secondary border border-white/5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-cv-green/10 border border-cv-green/20 flex items-center justify-center">
                      <Brain className="w-5 h-5 text-cv-green" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-cv-off-white">AI-Generated Summary</h3>
                      <p className="text-sm text-cv-light-gray/50">Updated 15 minutes ago</p>
                    </div>
                  </div>
                  <p className="text-cv-light-gray/70 leading-relaxed mb-6">
                    {asset.aiSummary}
                  </p>
                  <div className="space-y-3">
                    <h4 className="font-medium text-cv-off-white mb-3">Key Points</h4>
                    {asset.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-cv-green flex-shrink-0 mt-0.5" />
                        <span className="text-cv-light-gray/70">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-6 rounded-2xl bg-cv-secondary border border-white/5">
                  <h3 className="font-semibold text-cv-off-white mb-4">AI Sentiment Score</h3>
                  <div className="text-center mb-6">
                    <div className={`font-space font-bold text-6xl ${sentimentColor} mb-2`}>
                      {asset.aiScore}
                    </div>
                    <Badge variant="outline" className={`capitalize ${sentimentColor} bg-opacity-10`}>
                      {asset.aiSentiment}
                    </Badge>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-cv-light-gray/50">Bullish</span>
                        <span className="text-green-400">68%</span>
                      </div>
                      <Progress value={68} className="h-2 bg-cv-dark-gray" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-cv-light-gray/50">Neutral</span>
                        <span className="text-yellow-400">22%</span>
                      </div>
                      <Progress value={22} className="h-2 bg-cv-dark-gray" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-cv-light-gray/50">Bearish</span>
                        <span className="text-red-400">10%</span>
                      </div>
                      <Progress value={10} className="h-2 bg-cv-dark-gray" />
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="news">
              <div className="space-y-4">
                {asset.news.map((item) => (
                  <div 
                    key={item.id} 
                    className="p-5 rounded-xl bg-cv-secondary border border-white/5 hover:border-white/10 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <h4 className="font-medium text-cv-off-white">{item.title}</h4>
                      <SentimentIcon sentiment={item.sentiment} />
                    </div>
                    <div className="flex items-center gap-4 text-sm text-cv-light-gray/50">
                      <span>{item.source}</span>
                      <span>•</span>
                      <span>{item.time}</span>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="sentiment">
              <div className="p-6 rounded-2xl bg-cv-secondary border border-white/5">
                <div className="flex items-center gap-3 mb-6">
                  <Users className="w-6 h-6 text-cv-green" />
                  <div>
                    <h3 className="font-semibold text-cv-off-white">Community Sentiment</h3>
                    <p className="text-sm text-cv-light-gray/50">Based on 12,453 votes</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  <div className="text-center p-6 rounded-xl bg-green-500/5 border border-green-500/20">
                    <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-3" />
                    <div className="font-space font-bold text-3xl text-green-400 mb-1">68%</div>
                    <div className="text-sm text-cv-light-gray/50">Bullish</div>
                  </div>
                  <div className="text-center p-6 rounded-xl bg-yellow-500/5 border border-yellow-500/20">
                    <div className="w-8 h-8 rounded-full border-2 border-yellow-400 mx-auto mb-3" />
                    <div className="font-space font-bold text-3xl text-yellow-400 mb-1">22%</div>
                    <div className="text-sm text-cv-light-gray/50">Neutral</div>
                  </div>
                  <div className="text-center p-6 rounded-xl bg-red-500/5 border border-red-500/20">
                    <TrendingDown className="w-8 h-8 text-red-400 mx-auto mb-3" />
                    <div className="font-space font-bold text-3xl text-red-400 mb-1">10%</div>
                    <div className="text-sm text-cv-light-gray/50">Bearish</div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
