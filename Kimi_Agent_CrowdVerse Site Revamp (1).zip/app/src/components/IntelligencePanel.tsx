import { Link } from 'react-router-dom';
import type { LucideIcon } from 'lucide-react';
import { ArrowRight } from 'lucide-react';

interface IntelligencePanelProps {
  icon: LucideIcon;
  title: string;
  description: string;
  link: string;
  color: 'blue' | 'purple' | 'green';
}

const colorMap = {
  blue: {
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/20',
    text: 'text-blue-400',
    glow: 'hover:shadow-blue-500/20',
  },
  purple: {
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    text: 'text-purple-400',
    glow: 'hover:shadow-purple-500/20',
  },
  green: {
    bg: 'bg-cv-green/10',
    border: 'border-cv-green/20',
    text: 'text-cv-green',
    glow: 'hover:shadow-cv-green/20',
  },
};

export default function IntelligencePanel({
  icon: Icon,
  title,
  description,
  link,
  color,
}: IntelligencePanelProps) {
  const colors = colorMap[color];

  return (
    <Link
      to={link}
      className={`group relative p-6 sm:p-8 rounded-2xl bg-cv-secondary border border-white/5 
        transition-all duration-500 hover:border-opacity-40 hover:-translate-y-2
        ${colors.glow} hover:shadow-xl preserve-3d`}
    >
      {/* Icon */}
      <div
        className={`w-14 h-14 rounded-xl ${colors.bg} ${colors.border} border 
          flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500`}
      >
        <Icon className={`w-7 h-7 ${colors.text}`} />
      </div>

      {/* Content */}
      <h3 className="font-space font-bold text-xl sm:text-2xl text-cv-off-white mb-3">
        {title}
      </h3>
      <p className="text-cv-light-gray/70 leading-relaxed mb-6">
        {description}
      </p>

      {/* CTA */}
      <div className={`inline-flex items-center gap-2 ${colors.text} font-medium`}>
        <span>Explore</span>
        <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform duration-300" />
      </div>

      {/* Decorative gradient */}
      <div
        className={`absolute -bottom-20 -right-20 w-40 h-40 rounded-full ${colors.bg} 
          blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
      />
    </Link>
  );
}
