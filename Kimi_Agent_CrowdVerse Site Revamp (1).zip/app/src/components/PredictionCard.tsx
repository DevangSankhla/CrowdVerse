import { useState } from 'react';
import { TrendingUp, Users, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Prediction {
  id: number;
  question: string;
  category: string;
  votes: number;
  yesPercentage: number;
  noPercentage: number;
  trending: boolean;
}

interface PredictionCardProps {
  prediction: Prediction;
}

export default function PredictionCard({ prediction }: PredictionCardProps) {
  const [hasVoted, setHasVoted] = useState(false);
  const [selectedOption, setSelectedOption] = useState<'yes' | 'no' | null>(null);

  const handleVote = (option: 'yes' | 'no') => {
    setSelectedOption(option);
    setHasVoted(true);
  };

  return (
    <div className="group relative p-6 rounded-2xl bg-cv-secondary border border-white/5 
      transition-all duration-500 hover:border-purple-500/30 hover:shadow-lg">
      {/* Category & Trending */}
      <div className="flex items-center justify-between mb-4">
        <span className="px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-medium">
          {prediction.category}
        </span>
        {prediction.trending && (
          <div className="flex items-center gap-1 text-cv-green text-xs">
            <TrendingUp className="w-3 h-3" />
            <span>Trending</span>
          </div>
        )}
      </div>

      {/* Question */}
      <h3 className="font-space font-semibold text-lg text-cv-off-white mb-6">
        {prediction.question}
      </h3>

      {/* Vote Stats */}
      <div className="flex items-center gap-2 text-cv-light-gray/50 text-sm mb-6">
        <Users className="w-4 h-4" />
        <span>{prediction.votes.toLocaleString()} votes</span>
      </div>

      {/* Voting Section */}
      {!hasVoted ? (
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1 border-green-500/30 text-green-400 hover:bg-green-500/10 hover:border-green-500/50"
            onClick={() => handleVote('yes')}
          >
            Yes
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-red-500/30 text-red-400 hover:bg-red-500/10 hover:border-red-500/50"
            onClick={() => handleVote('no')}
          >
            No
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Yes Bar */}
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-green-400 flex items-center gap-2">
                Yes
                {selectedOption === 'yes' && <Check className="w-4 h-4" />}
              </span>
              <span className="text-cv-light-gray/70">{prediction.yesPercentage}%</span>
            </div>
            <div className="h-2 bg-cv-dark-gray rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-green-500 to-green-400 rounded-full liquid-fill"
                style={{ width: `${prediction.yesPercentage}%` }}
              />
            </div>
          </div>

          {/* No Bar */}
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-red-400 flex items-center gap-2">
                No
                {selectedOption === 'no' && <Check className="w-4 h-4" />}
              </span>
              <span className="text-cv-light-gray/70">{prediction.noPercentage}%</span>
            </div>
            <div className="h-2 bg-cv-dark-gray rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-500 to-red-400 rounded-full liquid-fill"
                style={{ width: `${prediction.noPercentage}%` }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
