import { TrendingUp, TrendingDown } from 'lucide-react';

const marketData = [
  { symbol: 'NIFTY 50', price: '23,482.85', change: '+1.21%', up: true },
  { symbol: 'SENSEX', price: '77,338.50', change: '+0.98%', up: true },
  { symbol: 'BTC/USD', price: '$67,234.00', change: '+3.29%', up: true },
  { symbol: 'ETH/USD', price: '$3,456.78', change: '+2.15%', up: true },
  { symbol: 'GOLD', price: '$2,345.60', change: '-0.45%', up: false },
  { symbol: 'SILVER', price: '$27.85', change: '+0.78%', up: true },
  { symbol: 'RELIANCE', price: '₹2,945.30', change: '+1.52%', up: true },
  { symbol: 'TCS', price: '₹4,123.45', change: '-0.32%', up: false },
  { symbol: 'INFY', price: '₹1,678.90', change: '+0.89%', up: true },
  { symbol: 'HDFC BANK', price: '₹1,456.70', change: '+0.65%', up: true },
];

export default function MarketTicker() {
  const doubledData = [...marketData, ...marketData];

  return (
    <div className="w-full bg-cv-secondary/80 backdrop-blur-sm border-y border-white/5 py-3 overflow-hidden">
      <div className="ticker-wrap">
        <div className="ticker-content">
          {doubledData.map((item, index) => (
            <div
              key={index}
              className="inline-flex items-center gap-3 px-6 border-r border-white/10"
            >
              <span className="font-semibold text-sm text-cv-off-white whitespace-nowrap">
                {item.symbol}
              </span>
              <span className="text-sm text-cv-light-gray/70 whitespace-nowrap">
                {item.price}
              </span>
              <span
                className={`inline-flex items-center gap-1 text-xs font-medium whitespace-nowrap ${
                  item.up ? 'text-green-400' : 'text-red-400'
                }`}
              >
                {item.up ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                {item.change}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
