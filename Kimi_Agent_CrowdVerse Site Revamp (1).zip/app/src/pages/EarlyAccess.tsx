import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Sparkles, 
  CheckCircle2, 
  TrendingUp, 
  Users, 
  Brain,
  Zap,
  Bell
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const benefits = [
  {
    icon: Brain,
    title: 'AI-Powered Insights',
    description: 'Get personalized market analysis and predictions powered by advanced AI algorithms.',
  },
  {
    icon: Users,
    title: 'Community Access',
    description: 'Join an exclusive community of forward-thinking investors and traders.',
  },
  {
    icon: TrendingUp,
    title: 'Early Feature Access',
    description: 'Be the first to try new features and tools before public release.',
  },
  {
    icon: Zap,
    title: 'Priority Support',
    description: 'Get dedicated support and direct feedback channels with our team.',
  },
];

const features = [
  'Real-time market intelligence',
  'AI-generated news summaries',
  'Community prediction markets',
  'Portfolio tracking & insights',
  'Sentiment analysis',
  'Price alerts & notifications',
];

export default function EarlyAccess() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsLoading(false);
    setIsSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center gap-2 text-cv-light-gray/50 hover:text-cv-green transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Side - Content */}
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cv-green/10 border border-cv-green/20 mb-6">
              <Sparkles className="w-4 h-4 text-cv-green" />
              <span className="text-sm font-medium text-cv-green">Limited Early Access</span>
            </div>

            <h1 className="font-space font-bold text-4xl sm:text-5xl text-cv-off-white mb-6 leading-tight">
              Be Among the First to Experience{' '}
              <span className="text-cv-green">CrowdVerse</span>
            </h1>

            <p className="text-cv-light-gray/70 text-lg mb-10 leading-relaxed">
              Join thousands of early adopters who are shaping the future of AI-powered 
              community intelligence. Get exclusive access to our platform before the public launch.
            </p>

            {/* Benefits Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
              {benefits.map((benefit, index) => {
                const Icon = benefit.icon;
                return (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-cv-green/10 border border-cv-green/20 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-cv-green" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-cv-off-white mb-1">{benefit.title}</h3>
                      <p className="text-sm text-cv-light-gray/70">{benefit.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Features List */}
            <div className="p-6 rounded-2xl bg-cv-secondary border border-white/5">
              <h3 className="font-semibold text-cv-off-white mb-4">What You'll Get</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-cv-green flex-shrink-0" />
                    <span className="text-sm text-cv-light-gray/70">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Side - Form */}
          <div className="lg:pl-8">
            <div className="p-8 rounded-2xl bg-cv-secondary border border-white/5">
              {!isSubmitted ? (
                <>
                  <div className="text-center mb-8">
                    <div className="w-16 h-16 rounded-2xl bg-cv-green/10 border border-cv-green/20 flex items-center justify-center mx-auto mb-4">
                      <Bell className="w-8 h-8 text-cv-green" />
                    </div>
                    <h2 className="font-space font-bold text-2xl text-cv-off-white mb-2">
                      Get Early Access
                    </h2>
                    <p className="text-cv-light-gray/70">
                      Fill in your details and we'll notify you when your spot is ready.
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <Label htmlFor="name" className="text-cv-off-white mb-2 block">
                        Full Name
                      </Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Enter your full name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        className="bg-cv-black border-white/10 text-cv-off-white placeholder:text-cv-light-gray/40 focus:border-cv-green/50"
                      />
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-cv-off-white mb-2 block">
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="bg-cv-black border-white/10 text-cv-off-white placeholder:text-cv-light-gray/40 focus:border-cv-green/50"
                      />
                    </div>

                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-cv-green text-cv-black hover:bg-cv-green-dark font-semibold py-6 text-lg rounded-xl transition-all duration-300 hover:shadow-glow disabled:opacity-50"
                    >
                      {isLoading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 border-2 border-cv-black/30 border-t-cv-black rounded-full animate-spin" />
                          <span>Joining...</span>
                        </div>
                      ) : (
                        'Join Early Access'
                      )}
                    </Button>

                    <p className="text-center text-xs text-cv-light-gray/50">
                      By joining, you agree to our Terms of Service and Privacy Policy.
                      No spam, unsubscribe anytime.
                    </p>
                  </form>
                </>
              ) : (
                <div className="text-center py-8">
                  <div className="w-20 h-20 rounded-full bg-cv-green/10 border border-cv-green/20 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10 text-cv-green" />
                  </div>
                  <h2 className="font-space font-bold text-2xl text-cv-off-white mb-3">
                    You're on the List!
                  </h2>
                  <p className="text-cv-light-gray/70 mb-6">
                    Thanks for signing up! We'll send you an email at{' '}
                    <span className="text-cv-green">{email}</span> when your early access is ready.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Link to="/">
                      <Button variant="outline" className="border-white/20 text-cv-off-white hover:bg-white/5">
                        Back to Home
                      </Button>
                    </Link>
                    <Link to="/dashboard">
                      <Button className="bg-cv-green text-cv-black hover:bg-cv-green-dark">
                        Explore Dashboard
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* Social Proof */}
            <div className="mt-6 text-center">
              <p className="text-sm text-cv-light-gray/50 mb-3">
                Joined by professionals from
              </p>
              <div className="flex items-center justify-center gap-6 opacity-50">
                {['Google', 'Microsoft', 'Amazon', 'Meta'].map((company) => (
                  <span key={company} className="text-sm font-medium text-cv-light-gray/70">
                    {company}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
