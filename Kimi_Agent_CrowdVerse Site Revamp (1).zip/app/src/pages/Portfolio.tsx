import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Wallet, 
  ArrowUpRight,
  ArrowDownRight,
  PieChart,
  Brain,
  AlertCircle,
  CheckCircle2,
  Clock
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Holding {
  symbol: string;
  name: string;
  quantity: number;
  avgPrice: string;
  currentPrice: string;
  value: string;
  pnl: string;
  pnlPercent: string;
  up: boolean;
}

const portfolioData = {
  totalValue: '₹12,45,678',
  dayChange: '+₹23,456',
  dayChangePercent: '+1.92%',
  totalPnl: '+₹1,87,432',
  totalPnlPercent: '+17.7%',
  up: true,
};

const holdings: Holding[] = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', quantity: 50, avgPrice: '₹2,450.00', currentPrice: '₹2,945.30', value: '₹1,47,265', pnl: '+₹24,765', pnlPercent: '+20.2%', up: true },
  { symbol: 'TCS', name: 'Tata Consultancy', quantity: 25, avgPrice: '₹3,800.00', currentPrice: '₹4,123.45', value: '₹1,03,086', pnl: '+₹8,086', pnlPercent: '+8.5%', up: true },
  { symbol: 'INFY', name: 'Infosys Ltd', quantity: 100, avgPrice: '₹1,550.00', currentPrice: '₹1,678.90', value: '₹1,67,890', pnl: '+₹12,890', pnlPercent: '+8.3%', up: true },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', quantity: 75, avgPrice: '₹1,520.00', currentPrice: '₹1,456.70', value: '₹1,09,252', pnl: '-₹4,747', pnlPercent: '-4.2%', up: false },
  { symbol: 'BTC', name: 'Bitcoin', quantity: 0.5, avgPrice: '$45,000.00', currentPrice: '$67,234.00', value: '$33,617', pnl: '+$11,117', pnlPercent: '+49.4%', up: true },
];

const allocation = [
  { category: 'Stocks', percentage: 65, color: 'bg-blue-500' },
  { category: 'Crypto', percentage: 20, color: 'bg-cv-green' },
  { category: 'Commodities', percentage: 10, color: 'bg-yellow-500' },
  { category: 'Cash', percentage: 5, color: 'bg-cv-light-gray' },
];

const aiInsights = [
  {
    type: 'recommendation',
    title: 'Consider increasing HDFC Bank position',
    description: 'Based on recent price correction and strong fundamentals, this could be a good entry point.',
    confidence: 78,
  },
  {
    type: 'alert',
    title: 'Bitcoin showing overbought signals',
    description: 'Technical indicators suggest taking some profits at current levels.',
    confidence: 65,
  },
  {
    type: 'insight',
    title: 'Portfolio well-diversified',
    description: 'Your current allocation aligns well with moderate risk profile.',
    confidence: 92,
  },
];

export default function Portfolio() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.gsap-portfolio-item').forEach((el, i) => {
        gsap.fromTo(
          el,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: el,
              start: 'top 90%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={sectionRef} className="min-h-screen bg-cv-black pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-cv-green/10 border border-cv-green/20 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-cv-green" />
            </div>
            <div>
              <div className="text-xs text-cv-green uppercase tracking-wider font-medium">Your Portfolio</div>
              <h1 className="font-space font-bold text-3xl sm:text-4xl text-cv-off-white">
                Portfolio Overview
              </h1>
            </div>
          </div>
          <p className="text-cv-light-gray/70 max-w-2xl">
            Track your investments, monitor performance, and get AI-powered insights to optimize your portfolio.
          </p>
        </div>

        {/* Portfolio Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <div className="gsap-portfolio-item p-6 rounded-2xl bg-cv-secondary border border-white/5">
            <div className="text-sm text-cv-light-gray/50 mb-2">Total Value</div>
            <div className="font-space font-bold text-3xl text-cv-off-white mb-2">
              {portfolioData.totalValue}
            </div>
            <div className={`flex items-center gap-1 text-sm ${portfolioData.up ? 'text-green-400' : 'text-red-400'}`}>
              {portfolioData.up ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              <span>{portfolioData.dayChange} ({portfolioData.dayChangePercent}) today</span>
            </div>
          </div>

          <div className="gsap-portfolio-item p-6 rounded-2xl bg-cv-secondary border border-white/5">
            <div className="text-sm text-cv-light-gray/50 mb-2">Total P&L</div>
            <div className="font-space font-bold text-3xl text-green-400 mb-2">
              {portfolioData.totalPnl}
            </div>
            <div className="flex items-center gap-1 text-sm text-green-400">
              <ArrowUpRight className="w-4 h-4" />
              <span>{portfolioData.totalPnlPercent} all time</span>
            </div>
          </div>

          <div className="gsap-portfolio-item p-6 rounded-2xl bg-cv-secondary border border-white/5">
            <div className="text-sm text-cv-light-gray/50 mb-2">Holdings</div>
            <div className="font-space font-bold text-3xl text-cv-off-white mb-2">
              {holdings.length}
            </div>
            <div className="text-sm text-cv-light-gray/50">
              Across 3 asset classes
            </div>
          </div>

          <div className="gsap-portfolio-item p-6 rounded-2xl bg-cv-secondary border border-white/5">
            <div className="text-sm text-cv-light-gray/50 mb-2">AI Health Score</div>
            <div className="font-space font-bold text-3xl text-cv-green mb-2">
              82/100
            </div>
            <div className="text-sm text-cv-light-gray/50">
              Well diversified
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Holdings Table */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl bg-cv-secondary border border-white/5 overflow-hidden">
              <div className="p-6 border-b border-white/5">
                <h3 className="font-space font-bold text-xl text-cv-off-white">Your Holdings</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left py-4 px-6 text-cv-light-gray/50 font-medium text-sm">Asset</th>
                      <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Qty</th>
                      <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Avg Price</th>
                      <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Current</th>
                      <th className="text-right py-4 px-4 text-cv-light-gray/50 font-medium text-sm">Value</th>
                      <th className="text-right py-4 px-6 text-cv-light-gray/50 font-medium text-sm">P&L</th>
                    </tr>
                  </thead>
                  <tbody>
                    {holdings.map((holding) => (
                      <tr 
                        key={holding.symbol} 
                        className="border-b border-white/5 hover:bg-white/5 transition-colors"
                      >
                        <td className="py-4 px-6">
                          <div>
                            <div className="font-semibold text-cv-off-white">{holding.symbol}</div>
                            <div className="text-xs text-cv-light-gray/50">{holding.name}</div>
                          </div>
                        </td>
                        <td className="text-right py-4 px-4 text-cv-off-white">
                          {holding.quantity}
                        </td>
                        <td className="text-right py-4 px-4 text-cv-light-gray/70">
                          {holding.avgPrice}
                        </td>
                        <td className="text-right py-4 px-4 text-cv-off-white">
                          {holding.currentPrice}
                        </td>
                        <td className="text-right py-4 px-4 font-medium text-cv-off-white">
                          {holding.value}
                        </td>
                        <td className="text-right py-4 px-6">
                          <div className={`${holding.up ? 'text-green-400' : 'text-red-400'}`}>
                            <div className="font-medium">{holding.pnl}</div>
                            <div className="text-xs">{holding.pnlPercent}</div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Allocation */}
            <div className="mt-6 p-6 rounded-2xl bg-cv-secondary border border-white/5">
              <div className="flex items-center gap-3 mb-6">
                <PieChart className="w-5 h-5 text-cv-green" />
                <h3 className="font-space font-bold text-xl text-cv-off-white">Asset Allocation</h3>
              </div>
              <div className="space-y-6">
                {allocation.map((item) => (
                  <div key={item.category}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-cv-off-white">{item.category}</span>
                      <span className="font-semibold text-cv-off-white">{item.percentage}%</span>
                    </div>
                    <div className="h-3 bg-cv-dark-gray rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${item.color} rounded-full transition-all duration-1000`}
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* AI Insights */}
          <div className="gsap-portfolio-item">
            <div className="p-6 rounded-2xl bg-cv-secondary border border-white/5">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-cv-green/10 border border-cv-green/20 flex items-center justify-center">
                  <Brain className="w-5 h-5 text-cv-green" />
                </div>
                <div>
                  <h3 className="font-semibold text-cv-off-white">AI Insights</h3>
                  <p className="text-sm text-cv-light-gray/50">Personalized recommendations</p>
                </div>
              </div>

              <div className="space-y-4">
                {aiInsights.map((insight, index) => (
                  <div 
                    key={index} 
                    className="p-4 rounded-xl bg-cv-black/50 border border-white/5 hover:border-white/10 transition-colors"
                  >
                    <div className="flex items-start gap-3 mb-3">
                      {insight.type === 'recommendation' && <CheckCircle2 className="w-5 h-5 text-cv-green flex-shrink-0" />}
                      {insight.type === 'alert' && <AlertCircle className="w-5 h-5 text-orange-400 flex-shrink-0" />}
                      {insight.type === 'insight' && <Brain className="w-5 h-5 text-blue-400 flex-shrink-0" />}
                      <div>
                        <h4 className="font-medium text-cv-off-white text-sm mb-1">{insight.title}</h4>
                        <p className="text-xs text-cv-light-gray/70">{insight.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-cv-dark-gray rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-cv-green rounded-full"
                          style={{ width: `${insight.confidence}%` }}
                        />
                      </div>
                      <span className="text-xs text-cv-light-gray/50">{insight.confidence}% confidence</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-white/5">
                <div className="flex items-center gap-2 text-sm text-cv-light-gray/50">
                  <Clock className="w-4 h-4" />
                  <span>Last updated 15 minutes ago</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
